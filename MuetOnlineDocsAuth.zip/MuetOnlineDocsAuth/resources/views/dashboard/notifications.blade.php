@extends('layouts.layout')

@section('content')

<div class="content-wrap">
          <div class="main">
              <div class="container-fluid">
      
 <main role="main">
      <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded box-shadow web_back_color">
        <img class="mr-3" src="/img/logo.png" alt="" width="48" height="48">
        <div class="lh-100">
          <h6 class="mb-0 text-white lh-100" style="letter-spacing: 3px;">Notifications</h6>
        </div>
      </div>

      <div class="my-3 p-3 bg-white rounded box-shadow">
        <h5 class="border-bottom border-gray pb-2 mb-0" style="color:black;">My Notifications</h5>
        
        @forelse($result['myNotif'] as $notification)
        
        <div class="media text-muted pt-3">
          <img src="{{ asset('storage/uploads/staff/'.$notification->pic)}}" alt="" class="mr-2 rounded" style="width:48px;height: 48px;">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Updated  your {{$notification->colName}}</strong>
            {{$notification->name}} - {{$notification->staffid}} updated your {{$notification->colName}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>

        @empty

        <br>

            <p class="text-center media-body pb-3 mb-0 lh-125 border-bottom border-gray">
                No notifications in this section...
            </p>
        
        @endforelse

        <br>

        @if(session('accInfo')[0]->role==1)

          <h5 class="border-bottom border-gray pb-2 mb-0" style="color:black">General Notifications</h5>

        <h6 class="border-bottom border-gray pb-2 mb-0 ml-1 mt-3" style="color:black">
          Employee related notifications
        </h6>

        <!-- creations -->
        
        @foreach($result['crNotif'] as $notification)
        
        <div class="media text-muted pt-3">
          
          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Created account with id - {{$notification->id}}</strong>
            {{$notification->staffid}} created an employee account with id - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        <!-- updations -->

        @foreach($result['upNotif'] as $notification)
        
        <div class="media text-muted pt-3">
          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Updation were made to account with id - {{$notification->id}}</strong>
            {{$notification->staffid}} updated the {{$notification->colName}} of the account with id - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        <!-- Activated -->

        @foreach($result['activeEmpNotif'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:blue; ">Activated account with id - {{$notification->id}}</strong>
            {{$notification->staffid}} activated the employee account with id - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        <!-- deletions -->

        @foreach($result['delNotif'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:orange; ">Deactivated account with id - {{$notification->id}}</strong>
            {{$notification->staffid}} deactivated the employee account with id - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach


         <!-- permanent deletions -->

        @foreach($result['perDelNotif'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:red; ">Deleted account with id - {{$notification->id}}</strong>
            {{$notification->staffid}} permanently deleted the employee account with id - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        <h6 class="border-bottom border-gray mt-3 pb-2 mb-0 ml-1" style="color:black">
          Student related notifications
        </h6>

        @foreach($result['VerStd'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:green; ">Verified student with Rollno - {{$notification->id}}</strong>
            Employee - Id: {{$notification->staffid}} verified the student with rollno - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        @foreach($result['UpStdInfo'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; "> Updated student - rollno:  {{$notification->id}} {{$notification->colName}} </strong>

            @if($notification->comment!=null)

              Employee account - {{$notification->staffid}}
               updated 

              

               {{ $notification->colName == 'markObtInTh' ? 'Theory marks' : ($notification->colName == 'markObtInPr' ? 'Practical marks' : '$notification->colName')  }}


               in

               {{
                  $result['courseName'][$notification->comment]

               }} 

               of student with rollno

               {{$notification->id}}

           @else

              Employee account - {{$notification->staffid}}
               updated {{$notification->colName}} 

               of student with rollno

               {{$notification->id}}

           @endif

            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        @foreach($result['RepStd'] as $notification)
        
        <div class="media text-muted pt-3">

          <div class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px;color:orange">
            <strong class="d-block text-gray-dark">Reported student with Rollno - {{$notification->id}}</strong>
            Employee - Id: {{$notification->staffid}} Reported the student with rollno - {{$notification->id}}
            <br>

          <?php

          $jsonComment=json_decode($notification->comment)->problem;

          if($jsonComment[0]!=null || $jsonComment[1] !=null || $jsonComment[2] != null || $jsonComment[3]!=null ){

        ?>

        <br>

        <span style="color:gray;font-size: 12px;">
          Reasons mentioned for reporting are:
        </span>
        <?php

        }

        ?>

        @if($jsonComment[0]!=null )

           
            <p class="ml-1" style="color:black">   &bull; Mistakes in ' {{$jsonComment[0]}} ' information
           </p>
        
        @endif

        

        @if($jsonComment[1]!=null )

           <p class="ml-1" style="color:black">
              &bull; Mistakes in {{$jsonComment[1]}} information
           </p>
        
        @endif

        

         @if($jsonComment[2]!=null )

           <p class="ml-1" style="color:black">
              &bull; Mistakes in ' {{$jsonComment[2]}} ' information
           </p>
        
        @endif

        

         @if($jsonComment[3]!=null )

            <p class="ml-1" style="color:black">
              &bull; Mistakes in different sections of information
            </p>

        @endif

          <?php

              $jsonComment=json_decode($notification->comment)->comment;

          ?>
          
          @if($jsonComment!=null)

          <p class="mt-3" style="color:black;">          

              Employee message for reporting this student:<span style="color:tomato;font-size: 12px">" {{$jsonComment}} "</span>

          </p>
          @endif


            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </div>
        </div>
        
        @endforeach

        @foreach($result['ResStd'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:teal; ">Restored student with Rollno - {{$notification->id}}</strong>
            Employee - Id: {{$notification->staffid}} restored the student with rollno - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach


        @foreach($result['DelStd'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:orange; ">Deleted student with Rollno - {{$notification->id}}</strong>
            Employee - Id: {{$notification->staffid}} deleted the student with rollno - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        @foreach($result['PerDelStd'] as $notification)
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:red; ">Permanently Deleted student with Rollno - {{$notification->id}}</strong>
            Employee - Id: {{$notification->staffid}} permanently deleted the student with rollno - {{$notification->id}}
            <small class="pull-right"> 
              {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}
            </small> 
          </p>
        </div>
        
        @endforeach

        @endif
        </div>

    </main>
</div>
</div>
</div>
    @endsection