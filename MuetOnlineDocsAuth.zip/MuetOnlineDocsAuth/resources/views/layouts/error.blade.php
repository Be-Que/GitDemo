@if(count($errors))
<div class="alert alert-danger text-white" style="width: 100%" role="alert">
	<ul>
		@foreach($errors->all() as $err)
			<li>{{ucfirst($err)}}!</li>
		@endforeach
	</ul>
</div>
@endif