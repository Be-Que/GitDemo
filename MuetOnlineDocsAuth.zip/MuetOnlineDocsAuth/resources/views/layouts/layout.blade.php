
@yield('styles1')
    
    <!-- Styles For Main View -->
    <link href="/assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="/assets/css/lib/themify-icons.css" rel="stylesheet">
    <link href="/assets/css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="/assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

 @yield('styles2')

    <!-- Styles for InnerView -->
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" type="text/css" href="/css/style2.css">

<!-- changings -->
@include('layouts.sidebar')

@include('layouts.header')

<!-- end -->



    @yield('content')

    <!-- Scripts for InnerView -->
    <script src="/js/jquery.min.js"></script>
    <script src="/js/tether.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>

    <script src="/assets/js/lib/jquery.nanoscroller.min.js"></script>
        <!-- nano scroller -->
    <script src="/assets/js/lib/menubar/sidebar.js"></script>
    <script src="/assets/js/lib/preloader/pace.min.js"></script>


    @yield('bootstrap')

    <script src="/assets/js/scripts.js"></script>


    

    @yield('scripts')

    <script type="text/javascript">
        
        function checkedNotif(){

             $.get('{{ URL::to("/notification/checked") }}',function(data){
               if(data){
                    document.getElementById('notify').style.color="white"

                   // console.log('data'.data);

               }
            });

        }
    </script>