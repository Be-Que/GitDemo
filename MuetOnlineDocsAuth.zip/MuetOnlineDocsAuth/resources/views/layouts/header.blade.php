<!-- header -->

<div class="header web_back_color" style="background-color: #24273c;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-left">

                        <div class="hamburger sidebar-toggle text-white">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>

                    </div>

                     @yield('tabs')
                    <!--add button hoverover appearence settings 5/5/18 -->
                    <div class="float-right mt-0">

                        <ul class="row">
                             
                            @yield('buttons')

                            <li class="header-icon dib">

                                @if(session('accInfo')[0]->role!=1)

                                    @if(count($result['myNotif'])!=0)

                                        <i class="ti-bell" style="color:red;" onclick="checkedNotif()" id="notify"></i>

                                    @else

                                        <i class="ti-bell" style="color:white;" onclick="checkedNotif()" id="notify"></i>

                                    @endif

                                @else

                                    @if(count($result['myNotif'])!=0 || count($result['CrEmpNotif'])!=0 || count($result['UpEmpNotif'])!=0 || count($result['DelEmpNotif'])!=0 || 
                                    count($result['UpStdInfo'])!=0 || 
                                    count($result['VerStd'])!=0 ||
                                    count($result['RepStd'])!=0 || 
                                    count($result['DelStd'])!=0) 
                                    
                                        <i class="ti-bell" style="color:red;" onclick="checkedNotif()" id="notify"></i>
                                    
                                    @else

                                        <i class="ti-bell" style="color:white;" onclick="checkedNotif()" id="notify"></i>

                                    @endif


                                @endif

                                
                                <div class="drop-down  dropdown-menuForNotif">
                                    <div class="dropdown-content-heading">
                                        <span class="text-left">


                                            <!-- checking if is admin or someone else -->

                                        @if(session('accInfo')[0]->role!=1)

                                            @if(count($result['myNotif'])==0)

                                                No
                                            
                                            @endif

                                                Recent Notifications
                                        
                                        @else

                                            @if(

                                            count($result['myNotif'])==0 && count($result['CrEmpNotif'])==0 && count($result['UpEmpNotif'])==0 && count($result['DelEmpNotif'])==0 && 
                                            count($result['UpStdInfo'])==0 && 
                                            count($result['VerStd'])!=0 &&
                                            count($result['RepStd'])!=0 && 
                                            count($result['DelStd'])!=0

                                            )

                                                No

                                            @endif            

                                                Recent Notifications

                                        @endif 

                                        

                                    </span>
                                    </div>
                                    <div class="dropdown-content-body"> 
                                        <ul>

                                            <legend style="font-size: 12px" class="ml-2">My Notifications</legend>

                                            @foreach($result['myNotif'] as $notification)

                                             <li style="display: flex;">
                                                <a >
                                                    <img  

                                                    class="rounded-circle" 

                                                    style="width:40px; height: 30px" 

                                                    alt="user pic"

                                                    src=  "{{ asset('storage/uploads/staff/'.$notification->pic)}}" />
                                                    
                                                    &nbsp;&nbsp;&nbsp;


                                                    <div class="notification-content" style="display: inline;">
                                                        
                                                        <div class="notification-heading" style="display: inline;color:gray;">
                                                            
                                                            {{$notification->name}}
                                                        </div>
                                                        <div class="notification-text" style="display: inline;color:gray;">updated your {{$notification->colName}}</div>
                                                    </div>
                                                    <br>
                                                    <p class="pull-right">
                                                    <small class="notification-timestamp pull-right">

                                                            {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                    </small>
                                                    </p>
                                                </a>
                                            </li>
   

                                            @endforeach

                                            @if(session('accInfo')[0]->role==1)


                                                <legend style="font-size: 12px" class="ml-2">General Notifications</legend>

                                                <legend style="font-size: 12px;color:black;" class="ml-4">Employee related notifications</legend>

                                                @foreach($result['CrEmpNotif'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >

                                                        <div class="notification-content" style="display: inline;">
                                                            <div class="notification-text" style="display: inline;color:gray">
                                                                
                                                                 Employee account - 
                                                                {{$notification->staffid}}
                                                                 created the employee account with id {{$notification->id}}

                                                            </div>
                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach


                                                @foreach($result['UpEmpNotif'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        
                                                        <div class="notification-content" style="display: inline;color:black;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:gray;">

                                                                 Employee account - {{$notification->staffid}}
                                                                 updated the employee's  '{{$notification->id}}'

                                                                 {{$notification->colName}} 
                                                                
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                <!-- activated -->
                                                @foreach($result['ActiveEmpNotif'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:blue">
                                                                
                                                                Employee account -  {{$notification->id}}
                                                                 has been activated by the employee account  with id {{$notification->staffid}}


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['DelEmpNotif'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange">
                                                                
                                                                Employee account -  {{$notification->id}}
                                                                 has been deactived by the employee account  with id {{$notification->staffid}}


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach


                                                @foreach($result['PerDelEmpNotif'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:red">
                                                                
                                                                Employee account -  {{$notification->id}}
                                                                 has been permanently deleted by the employee account  with id {{$notification->staffid}}


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach


                                                <legend style="font-size: 12px;color:black;" class="ml-4">Students related notifications</legend>

                                                @foreach($result['VerStd'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:green;">

                                                                 Student - rollno: {{$notification->id}} has been verified by the employee - id:{{$notification->staffid}}

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['UpStdInfo'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:gray;">
                                                                
                                                                @if($notification->comment!=null)

                                                                    Employee account - {{$notification->staffid}}
                                                                     updated 

                                                                      {{ $notification->colName == 'markObtInTh' ? 'Theory marks' : ($notification->colName == 'markObtInPr' ? 'Practical marks' : '$notification->colName')  }} 

                                                                     in

                                                                     {{
                                                                        $result['courseName'][$notification->comment]

                                                                     }} 

                                                                     of student with rollno

                                                                     {{$notification->id}}

                                                                 @else

                                                                    Employee account - {{$notification->staffid}}
                                                                     updated {{$notification->colName}} 

                                                                     of student with rollno

                                                                     {{$notification->id}}

                                                                 @endif


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['RepStd'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange;">

                                                                 Student - rollno: {{$notification->id}} has been Reported by the employee - id:{{$notification->staffid}}

                                                                 <?php

                                                                    $jsonComment=json_decode($notification->comment)->problem;

                                                                    if($jsonComment[0]!=null || $jsonComment[1] !=null || $jsonComment[2] != null || $jsonComment[3]!=null ){

                                                                ?>

                                                                

                                                               <span style="color:gray"> Reasons mentioned for reporting are:
                                                                </span>
                                                                <?php

                                                                }

                                                                ?>

                                                                

                                                                    @if($jsonComment[0]!=null )

                                                                       
                                                                        <p class="ml-1" style="color:black">   &bull; Mistakes in ' {{$jsonComment[0]}} ' information
                                                                       </p>
                                                                    
                                                                    @endif

                                                                    

                                                                    @if($jsonComment[1]!=null )

                                                                       <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in {{$jsonComment[1]}} information
                                                                       </p>
                                                                    
                                                                    @endif

                                                                    

                                                                     @if($jsonComment[2]!=null )

                                                                       <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in ' {{$jsonComment[2]}} ' information
                                                                       </p>
                                                                    
                                                                    @endif

                                                                    

                                                                     @if($jsonComment[3]!=null )

                                                                        <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in different sections of information
                                                                        </p>

                                                                    @endif
                                                                    
                                                                <?php

                                                                    $jsonComment=json_decode($notification->comment)->comment;

                                                                ?>
                                                                
                                                                @if($jsonComment!=null)

                                                                    <span style="color: gray;">Employee message for reporting this student:
                                                                    </span> 
                                                                    <blockquote style="color:tomato">
                                                                        " {{$jsonComment}} "
                                                                    </blockquote>
                                                                @endif

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['ResStd'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:teal;">

                                                                 Student - rollno: {{$notification->id}} has been restored by the employee - id:{{$notification->staffid}}

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['DelStd'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange">

                                                                 Student - rollno: {{$notification->id}} has been deleted by the employee - id:{{$notification->staffid}}

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                                @foreach($result['PerDelStd'] as $notification)
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:red">

                                                                 Student - rollno: {{$notification->id}} has been permanently deleted by the employee - id:{{$notification->staffid}}

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                {{ \Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString() }}

                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                @endforeach

                                            @endif    
                                            <li class="text-center">
                                                
                                                <a href="/notifications" class="more-link">See All</a>

                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </li>

                            <li class="header-icon dib">
                                <span class="user-avatar">
                                    
                                    <img 
                                    
                                    src=  "/img/logo1.png"

                                    title="company logo"

         
                                   class="rounded-circle" style="width:40px; height: 30px" alt="user pic"> 

                                </span>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


