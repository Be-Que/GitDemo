<div class="modal fade " id="RForChange">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header bg-primary text-white">
<h6 class="modal-title text-white" id="addEModalLabel">Request for Change</h6>

</div>
<div class="modal-body">

<form class="form-horizontal" role="form" method="post" action="/student/sendEmail">
	@csrf
<div class="form-group">
<label for="email" class="form-control-label">Email Address</label>
<input type="email" class="form-control" required name="email">
</div>
<div class="form-group">
<label for="textarea" class="control-label">Body</label>
<textarea class="form-control" name="body" required></textarea>
</div>
<div class="pull-right">
<button class="btn btn-success" type="submit">Send</button>
<button type="button" class="btn btn-dark text-white" data-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>
</div>
