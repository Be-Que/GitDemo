@extends('layouts.layout')


@section('content')

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

<div class="col-md-12 ml-2">
<div class="card-user">

<div class="author ml-4">
<a href="#">

<!-- user image -->
<img class="avatar border-gray"

src=  "{{ asset('storage/uploads/students/'
.$res->pic)}}"

alt="...">


</a>
</div>
<div class="Username">
<p style="text-align: center;font-size: 2em;color: black;font-style: bold;font-family: 'Raleway', sans-serif;margin-bottom: 2px">

{{ucwords($res->fullname)}}

</p>
<p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px;letter-spacing: 2px" class="lead">
 {{ucwords(json_decode($res->currentPosition)->curPos)}}
</p>
</div>
<hr>

<!-- Nav tabs -->
<ul class="nav nav-pills nav-fill customtab2" role="tablist" >
<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#about" role="tab"><span><i class="fa fa-user-circle"></i> About me</span></a> </li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#role" role="tab"> <span><i class=" ti-blackboard"></i> Addmission Information </span></a>
</li>
</ul>
<!-- Tab panes -->
<div class="tab-content">
<div class="tab-pane active" id="about" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div>
<div class="contact-information">
<legend>Personal Information</legend>

<div class="phone-content">
<span class="contact-title  ">Name:</span>
<span >
   {{ucwords($res->fullname)}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Father Name:</span>
<span>
   {{ucwords($res->fatherName)}}
</span>
    
</div>

<div class="phone-content">
<span class="contact-title  ">Surname:</span>
<span>
   {{ucwords($res->surname)}}
</span>
    
</div>
<div class="phone-content">
<span class="contact-title  ">Date of Birth:</span>
<span>
    {{$res->dob}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">CNIC:</span>
<span>
   {{$res->cnic}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Gender:</span>
<span >

    {{ $res->gender== 'm' ? 'Male' : 'Female' }} 

</span>
</div>



<legend>Residence & Contact Information</legend>

<div class="phone-content">
<span class="contact-title  ">Email:</span>
<span >
    {{$res->email}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Address:</span>
<span >

  {{$res->addr}}

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Country:</span>
<span >

  {{ucwords($res->country)}}

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Province:</span>
<span >

  {{ucwords($res->province)}}

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Domicile:</span>
<span>
{{ucwords($res->domicile)}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Mobile Number:</span>
<span>

{{$res->mbNo}}

</span>
</div>

</div>

</div>
</div>
</div>
</div>
</div>
<!-- tab2 -->
<div class="tab-pane p-20" id="role" role="tabpanel">
<div class="row">
<div class="basic-information" style="width: 100%">

<legend>Admission Information</legend>

<div class="contact-information">

<div class="phone-content" style="font-family: 'Raleway', sans-serif;" >
<span class="contact-title  ">Roll no:</span>

<span>
   {{strtoupper($res->rollNo)}}
</span>

</div>

<div class="phone-content" style="font-family: 'Raleway', sans-serif;" >
<span class="contact-title  ">Enrollment number:</span>

<span>
   {{$res->enrollmentNo}}
</span>

</div>

<div class="phone-content">
<span class="contact-title  ">Date of addmission:</span>
<span >
   {{$res->doa}}
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Programme:</span>
<span>
   {{strtoupper($res->programme)}}
</span>
    
</div>
<div class="phone-content">
<span class="contact-title  ">Department Name:</span>
<span>
    {{ucwords($res->dept)}}
</span>
</div>

</div>

</div>
</div>
</div>
</div>


</div>
</div>

</main>

@endsection

@section('scripts')

<script type="text/javascript">
  $('#notify').hide();
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
<script type="text/javascript">

document.getElementById('dashboard').classList.remove('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');

</script>

@endsection
