<legend class="text-center">OBE Based System</legend>
<div class="col-sm-12">
<form class="form-horizontal" role="form" method="post" action="#">
    <table class="table table-striped" id="myTable">
        <thead class="thead">
            <tr>
                <th>#</th>
                <th>PLO</th>
                <th>Percentage</th>
                <th>Grade</th>
                <th>Remarks</th>
            </tr>
        </thead>
    <tbody>
@foreach($ploRes as $percentage)
<tr>
<td scope="row">{{$loop->index+1}}</td>
<td>PLO{{$loop->index+1}}</td>
<td>{{$percentage}}</td>

@if($percentage>=85 && $percentage<=100)
<td>A+</td>
<td>Excellent</td>
@elseif($percentage>=80 && $percentage<=84)
<td>A</td>
<td>Very Good</td>

@elseif($percentage>=75 && $percentage<=79)
<td>B+</td>
<td>Good</td>

@elseif($percentage>=70 && $percentage<=74)
<td>B</td>
<td>Nice</td>

@elseif($percentage>=65 && $percentage<=69)
<td>C</td>
<td>PASS</td>

@elseif($percentage>=60 && $percentage<=64)
<td>D</td>
<td>PASS</td>

@elseif($percentage>=50 && $percentage<=59)
<td>E</td>
<td>PASS</td>

@else
<td>F</td>
<td>FAIL</td>


@endif
</tr>
@endforeach
</tbody>
</table>
<br>
    <div class="row">
        <div class="col-sm-12">
            <div class="pull-right">
                <!-- Cancel button removed from here 5/5/18 -->

<a href="#mydiv">
                <button class="btn btn-danger" style="border-radius:5px;"
                onclick="show()">Request For Change
            </button>
           </a> 
    <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>        
            </div>
            <br>
            <br>
 </div>
    </div>
</form>

</div>

<br>
<div id="mydiv" style="margin-left: 7%;margin-top: 5%; width: 80%;">
</div>