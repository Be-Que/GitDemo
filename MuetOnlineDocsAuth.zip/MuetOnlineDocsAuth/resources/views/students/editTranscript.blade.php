@if(strchr(strtolower($system->name),"obe")==TRUE)
<?php $property = 'readonly';?>
@else
<?php $property = '';?>
@endif


<legend class="text-center">C.G.P.A Based System
    <br><br><small class="lead">Roll no:{{strtoupper($user->rollNo)}}</small>
</legend>

<ul class="nav nav-tabs nav-fill   customtab2" role="tablist" id="myTab2">

<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#first" role="tab"><span> 1st Year</span></a> </li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#second" role="tab"> <span>2nd Year</span></a>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#third" role="tab"> <span> 3rd Year</span></a>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#final" role="tab"> <span> 4th/Final Year</span></a>
</li>


</ul>
<div class="tab-content" id="myTab2Content">
<div class="tab-pane active" id="first" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div class="col-sm-12">

<form class="form-horizontal" role="form" method="post" action="/transcript/update" id="firstform">
@csrf
<br>
<div class="alert alert-danger hidden" id="markserr1"
style="color: white;">
</div>
   
<input type="hidden" name="id" value="{{$user->rollNo}}">
@php $check = 0; @endphp

@foreach($examinfo as $info)

@if($check!=$info->sems)

@if($info->sems==1)
<legend class="text-center">First Semester</legend>

@elseif($info->sems==2)
<legend class="text-center">Second Semester</legend>
@endif
@endif
@php $check = $info->sems; @endphp

@if($info->IsTheory==1 && ($info->sems==1||$info->sems==2))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">

<label class="col-sm-12 col-form-label">
{{$info->courseName}}<sub>(THEORY)</sub>
</label>
  </div>
    </div>
     <!-- send courseCode to update record-->
    <input type="hidden" name="THcode[]" value="{{$info->courseCode}}">

     <!-- send semester to update record-->
    <input type="hidden" name="THsems[]" value="{{$info->sems}}">

    
<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    <input type="number" class="form-control" required readonly value="{{$info->maxMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info->maxMarks}}" name="maxmarksTH[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" required 
 value="{{$info->markObtInTh}}" name="marksobtTH[]" min="0"
 {{$property}}>
<!-- To track previos marks before updation-->

 <input type="hidden" name="oldmarksobtTH[]" value="{{$info->markObtInTh}}">
        </div>
    </div>
</div>
</div>
@endif
<!-- NOW FOR PRACTICAL MARKS-->

@if($info->IsPractical==1 && ($info->sems==1||$info->sems==2))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">
<label class="col-sm-8 col-form-label">
{{$info->courseName}}<sub>(PRACTICAL)</sub>
</label>
  </div>
    </div>
    <!-- send courseCode to update record-->
    <input type="hidden" name="PRcode[]" value="{{$info->courseCode}}"> 

    <!-- send courseCode to update record-->
    <input type="hidden" name="PRsems[]" value="{{$info->sems}}"> 

<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    
    <input type="number" class="form-control" required readonly value="{{$info->maximumMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info->maximumMarks}}" name="maxmarksPR[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" 
 value="{{$info->markObtInPr}}" required name="marksobtPR[]" min="0" 
 {{$property}}>
  
<!-- To track previos marks before updation-->
<input type="hidden" name="oldmarksobtPR[]" value="{{$info->markObtInPr}}">
   </div>
    </div>
</div>
</div>
@endif

@endforeach
@if(strchr(strtolower($system->name),"cgpa")==TRUE)
<div class="row" id="button">
<div class="col-sm-12">
<div class="pull-right">
    <input type="submit" name="submit" class="btn btn-success" value="Update" style="border-radius:5px;">
 <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
</div>
<br>
<br>
</div>
</div>
</form>
@endif

</div>
</div>
</div>
</div>
</div>
<!-- 2nd Year -->
<div class="tab-pane  p-20" id="second" role="tabpanel">
<br>
<div class="col-sm-12">

<form class="form-horizontal" role="form" method="post" action="/transcript/update" id="secondform">

@csrf

<div class="alert alert-danger hidden" id="markserr2"
style="color: white;">
</div>
   
<input type="hidden" name="id" value="{{$user->rollNo}}">
@php $check1 = 3; @endphp

@foreach($examinfo as $info1)

@if($check1==$info1->sems)

@if($info1->sems==3)
<legend class="text-center">First Semester</legend>
@php ++$check1; @endphp
@elseif($info1->sems==4)
<legend class="text-center">Second Semester</legend>
@php ++$check1; @endphp
@endif

@endif



@if($info1->IsTheory==1 && ($info1->sems==3||$info1->sems==4))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">

<label class="col-sm-12 col-form-label">
{{$info1->courseName}}<sub>(THEORY)</sub>
</label>
  </div>
    </div>
     <!-- send courseCode to update record-->
    <input type="hidden" name="THcode[]" value="{{$info1->courseCode}}">

     <!-- send semester to update record-->
    <input type="hidden" name="THsems[]" value="{{$info1->sems}}">

    
<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    <input type="number" class="form-control" required readonly value="{{$info1->maxMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info1->maxMarks}}" name="maxmarksTH[]">

    </div>
</div>
</div>

<div class="col-sm-4">
<div class="form-group  row" id="obtmarks">
       
<label class="col-sm-4 col-form-label">Marks Obtained:</label>
<div class="col-sm-8 ">
  <input type="number" class="form-control" required 
 value="{{$info1->markObtInTh}}" name="marksobtTH[]" min="0"
 {{$property}}>
<!-- To track previos marks before updation-->

 <input type="hidden" name="oldmarksobtTH[]" value="{{$info1->markObtInTh}}">
        </div>
    </div>
</div>
</div>
@endif
<!-- NOW FOR PRACTICAL MARKS-->

@if($info1->IsPractical==1 && ($info1->sems==3||$info1->sems==4))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">
<label class="col-sm-8 col-form-label">
{{$info1->courseName}}<sub>(PRACTICAL)</sub>
</label>
  </div>
    </div>
    <!-- send courseCode to update record-->
    <input type="hidden" name="PRcode[]" value="{{$info1->courseCode}}"> 

    <!-- send courseCode to update record-->
    <input type="hidden" name="PRsems[]" value="{{$info1->sems}}"> 

<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    
    <input type="number" class="form-control" required readonly value="{{$info1->maximumMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info1->maximumMarks}}" name="maxmarksPR[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" 
 value="{{$info1->markObtInPr}}" required name="marksobtPR[]" min="0" 
 {{$property}}>
  
<!-- To track previos marks before updation-->
<input type="hidden" name="oldmarksobtPR[]" value="{{$info1->markObtInPr}}">
   </div>
    </div>
</div>
</div>
@endif

@endforeach

@if(strchr(strtolower($system->name),"cgpa")==TRUE)
<div class="row" id="button">
<div class="col-sm-12">
<div class="pull-right">
    <input type="submit" name="submit" class="btn btn-success" value="Update" style="border-radius:5px;">
<button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
</div>
<br>
<br>
</div>
</div>
</form>
@endif
</div>
</div>

<!--3rd Year-->
<div class="tab-pane p-20" id="third" role="tabpanel">
<br>
<div class="col-sm-12">

<form class="form-horizontal" role="form" method="post" action="/transcript/update" id="thirdform">
@csrf

<div class="alert alert-danger hidden" id="markserr3"
style="color: white;">
</div>
   
<input type="hidden" name="id" value="{{$user->rollNo}}">
@php $check2 = 5; @endphp

@foreach($examinfo as $info2)


@if($check2==$info2->sems)

@if($info2->sems==5)
<legend class="text-center">First Semester</legend>
@php ++$check2; @endphp

@elseif($info2->sems==6)
<legend class="text-center">Second Semester</legend>
@php ++$check2; @endphp
@endif

@endif


@if($info2->IsTheory==1 && ($info2->sems==5||$info2->sems==6))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">

<label class="col-sm-12 col-form-label">
{{$info2->courseName}}<sub>(THEORY)</sub>
</label>
  </div>
    </div>
     <!-- send courseCode to update record-->
    <input type="hidden" name="THcode[]" value="{{$info2->courseCode}}">

     <!-- send semester to update record-->
    <input type="hidden" name="THsems[]" value="{{$info2->sems}}">

    
<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    <input type="number" class="form-control" required readonly value="{{$info2->maxMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info2->maxMarks}}" name="maxmarksTH[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" required 
 value="{{$info2->markObtInTh}}" name="marksobtTH[]" min="0"
 {{$property}}>
<!-- To track previos marks before updation-->

 <input type="hidden" name="oldmarksobtTH[]" value="{{$info2->markObtInTh}}">
        </div>
    </div>
</div>
</div>
@endif
<!-- NOW FOR PRACTICAL MARKS-->

@if($info2->IsPractical==1 && ($info2->sems==5||$info2->sems==6))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">
<label class="col-sm-8 col-form-label">
{{$info2->courseName}}<sub>(PRACTICAL)</sub>
</label>
  </div>
    </div>
    <!-- send courseCode to update record-->
    <input type="hidden" name="PRcode[]" value="{{$info2->courseCode}}"> 

    <!-- send courseCode to update record-->
    <input type="hidden" name="PRsems[]" value="{{$info2->sems}}"> 

<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    
    <input type="number" class="form-control" required readonly value="{{$info2->maximumMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info2->maximumMarks}}" name="maxmarksPR[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" 
 value="{{$info2->markObtInPr}}" required name="marksobtPR[]" min="0" 
 {{$property}}>
  
<!-- To track previos marks before updation-->
<input type="hidden" name="oldmarksobtPR[]" value="{{$info2->markObtInPr}}">
   </div>
    </div>
</div>
</div>
@endif
@endforeach

@if(strchr(strtolower($system->name),"cgpa")==TRUE)
<div class="row" id="button">
<div class="col-sm-12">
<div class="pull-right">
    <input type="submit" name="submit" class="btn btn-success" value="Update" style="border-radius:5px;">
       <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
</div>
<br>
<br>
</div>
</div>
</form>
@endif

</div>
</div>
<!-- Four year-->
<div class="tab-pane p-20" id="final" role="tabpanel">
<br>
<div class="col-sm-12">

<form class="form-horizontal" role="form" method="post" action="/transcript/update" id="fourform">

@csrf

<div class="alert alert-danger hidden" id="markserr4"
style="color: white;">
</div>
   
<input type="hidden" name="id" value="{{$user->rollNo}}">
@php $check3 = 7; @endphp

@foreach($examinfo as $info3)

@if($check3==$info3->sems)

@if($info3->sems==7)
<legend class="text-center">First Semester</legend>
@php ++$check3; @endphp

@elseif($info3->sems==8)
<legend class="text-center">Second Semester</legend>
@php ++$check3; @endphp
@endif

@endif

@if($info3->IsTheory==1 && ($info3->sems==7 ||$info3->sems==8))

 

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">

<label class="col-sm-12 col-form-label">
{{$info3->courseName}}<sub>(THEORY)</sub>
</label>
  </div>
    </div>
     <!-- send courseCode to update record-->
    <input type="hidden" name="THcode[]" value="{{$info3->courseCode}}">

     <!-- send semester to update record-->
    <input type="hidden" name="THsems[]" value="{{$info3->sems}}">

    
<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    <input type="number" class="form-control" required readonly value="{{$info3->maxMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info3->maxMarks}}" name="maxmarksTH[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" required 
 value="{{$info3->markObtInTh}}" name="marksobtTH[]" min="0"
 {{$property}}>
<!-- To track previos marks before updation-->

 <input type="hidden" name="oldmarksobtTH[]" value="{{$info3->markObtInTh}}">
        </div>
    </div>
</div>
</div>
@endif
<!-- NOW FOR PRACTICAL MARKS-->

@if($info3->IsPractical==1 && ($info3->sems==7||$info3->sems==8))

<!-- ROwsss -->
<div class="row">
    <div class="col-sm-4">
        <div class="form-group  row">
<label class="col-sm-8 col-form-label">
{{$info3->courseName}}<sub>(PRACTICAL)</sub>
</label>
  </div>
    </div>
    <!-- send courseCode to update record-->
    <input type="hidden" name="PRcode[]" value="{{$info3->courseCode}}"> 

    <!-- send courseCode to update record-->
    <input type="hidden" name="PRsems[]" value="{{$info3->sems}}"> 

<div class="col-sm-4">
<div class="form-group  row" id="maxmarks">
<label class="col-sm-4 col-form-label">Max Marks:</label>
    <div class="col-sm-8 " id="max">
    
    <input type="number" class="form-control" required readonly value="{{$info3->maximumMarks}}" >
   
    <input type="hidden" class="form-control" required 
 value="{{$info3->maximumMarks}}" name="maxmarksPR[]">

    </div>
</div>
</div>
<div class="col-sm-4">
    <div class="form-group  row" id="obtmarks">
       
        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
        <div class="col-sm-8 ">
  <input type="number" class="form-control" 
 value="{{$info3->markObtInPr}}" required name="marksobtPR[]" min="0" 
 {{$property}}>
  
<!-- To track previos marks before updation-->
<input type="hidden" name="oldmarksobtPR[]" value="{{$info3->markObtInPr}}">
   </div>
    </div>
</div>
</div>
@endif

@endforeach
@if(strchr(strtolower($system->name),"cgpa")==TRUE)
<div class="row" id="button">
<div class="col-sm-12">
<div class="pull-right">
    <input type="submit" name="submit" class="btn btn-success" value="Update" style="border-radius:5px;">
  <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
</div>
<br>
<br>
</div>
</div>
</form>
@endif


</div>
</div>
</div>





