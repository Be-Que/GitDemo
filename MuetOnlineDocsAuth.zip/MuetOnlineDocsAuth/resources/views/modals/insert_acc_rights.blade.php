<!-- add role modal -->

<div class="modal fade" id="addRole">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header web_back_color text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Create a Role</h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">
<form class="form-horizontal" role="form" method="post" action="/account_rights" id="addRoleForm">

@csrf

<div class=" text-center">

<div class="alert alert-danger text-white" role="alert" id="error" style="display:none;color:white;text-align: left;">
    <!-- display errors here  -->
</div>

<br>
<div class="row">
    <div class="col-sm-12">
        <br>

        <div class="form-group row">
            <label for="role_name" class="col-sm-4 col-form-label mt-2">Role Name:</label>
            <div class="col-sm-6">
                <input type="text" name="role_name" class="form-control" id="role_name" placeholder="Enter role name" required>
            </div>
        </div>

        <div class="form-group row">
            <label for="role_desc" class="col-sm-4 col-form-label mt-2">Role Description:</label>
            <div class="col-sm-6">
                <input type="text" name="role_desc" class="form-control" id="role_desc" placeholder="Enter role description" required>
            </div>
        </div>

        <legend>Select Previleges for this role</legend>

        <div id="prevs">

            @foreach($res as $value)

            <div class="row">
        <div class="form-group row ml-5 pl-5">
            <input class="form-check-input" type="checkbox" value="1" id= '{{$value->id}}'  name="{{$value->id}}" onchange="clicked(this.id)">

            <label class="form-check-label" style="color:black" for="label" id='pd{{$value->id}}'>{{$value->prevDesc}}</label>

        </div>
    </div>

            @endforeach

        </div>

        <div class="form-group row" id="submitButton">
            <div class="col-sm-12">
                <div class="pull-right">
                    
                    <button type="button" class="btn btn-primary" style="border-radius:5px;" id="submitFormChanges" data-prevs="{{$res}}">Create</button>

                    <button style="border-radius:5px;" type="button" class="btn btn-dark text-white" data-dismiss="modal">Cancel</button>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
