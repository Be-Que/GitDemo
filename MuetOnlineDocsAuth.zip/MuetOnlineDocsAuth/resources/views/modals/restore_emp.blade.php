<div class="modal fade" id="resemp">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header text-white" style="background-color: orange;">
                    <h6 class="modal-title text-white" id="addEModalLabel">Are you sure?</h6>
                     <button class="close text-white" data-dismiss="modal">
                     <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <p>Do you really want to activate employee account  {{$id}} - {{$name}}?</p>

                    <form action="/employees/restore" method="post" id="deleteform">

                        <input type="hidden" name="id" value="{{$id}}">
                        
                        @csrf

                        <div class="pull-right">                       

                            <button type="button" id="submitdelete" class="btn btn-success"  style="border-radius:5px;">Activate</button>

                            <button  type="button" class="btn btn-dark text-white" data-dismiss="modal"  style="border-radius:5px;">Cancel</button>

                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
