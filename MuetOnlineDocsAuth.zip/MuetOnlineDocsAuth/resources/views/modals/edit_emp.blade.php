<!-- Edit Employee Info Modal start-->
<div class="modal  fade" id="editempM" >
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header text-white bg-success">
<h5 class="modal-title text-white" id="addEModalLabel">Update Employee Profile - {{ucwords($res['empDetails'][0]->name)}}</h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">

<form class="form-horizontal" role="form" method="post" action="/employees/edit/saveChanges" id="editemp" enctype="multipart/form-data" > 

<input type="hidden" name="id" id="empstaffid" value="{{$res['empDetails'][0]->id}}">

<input type="hidden" class="form-control" id="prev_email"  name="prev_email" value="{{$res['empDetails'][0]->email}}">

<input type="hidden" class="form-control" id="prev_select"  name="prev_select" value="{{$res['empDetails'][0]->roleId}}">


<div class="col-sm-12">

@csrf

<div class=" text-center">
<br>
<legend>Personal Information</legend>

<div class="alert alert-danger text-white" role="alert" id="imgeerror" style="display:none;color:white;">
Image should be less than 64 kb in size and image should have jpg or png extension!
</div>

<div class="alert alert-danger" role="alert" id="error" style="display:none;color:white;">
<!-- display errors here  -->
</div>

<div class="row">
<div class="col-sm-8" id="formElements">
<br>

<div class="form-group row" >
<label for="Name" class="col-sm-3 col-form-label mt-2">Email</label>
<div class="col-sm-6">
<input type="email" name="email" class="form-control" id="email" placeholder="Email" value="{{$res['empDetails'][0]->email}}">

</div>
</div>


<div class="form-group row">

<div class="alert alert-primary" id="passrules" style="color:white;;text-align: left; width: 80%;margin-left: 5%;font-size: 0.9em;border: 1px solid white;border-radius: 5px;display: none;">

<ul>
<li>
&bull; Password should have atleast 6 characters.
</li>
<li>
&bull; Password should have one Uppercase character.
</li>
<li>
&bull; Password should have one Lowercase character.
</li>
</ul>
</div>

</div>

<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label mt-2">Password</label>
<div class="col-sm-6">
<input name="password" class="form-control" id="password" placeholder="xxxxxxx"  type="password" >
</div>
</div>

<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label mt-2">Confirm Password</label>
<div class="col-sm-6">
<input  name="password_confirmation" class="form-control" id="password_confirmation" placeholder="xxxxxxx" type="password">
</div>
</div>


<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label mt-2">Role</label>
<div class="col-sm-6">
<select class="form-control selectpicker" id='roleSelect' name="select" data-roles="{{$res['rolePrevs']}}" data-prevs="{{$res['prevs']}}">

<option name="Custom role" value="Custom role">Custom role</option>

<option name="{{$res['empDetails'][0]->roleId}}" value="{{$res['empDetails'][0]->roleId}}" selected>

{{ucwords($res['empDetails'][0]->role)}}

</option>

@foreach($res['roles'] as $value)

<option name='{{$value->id}}' value="{{$value->id}}">

{{ucwords($value->name)}}

</option>

@endforeach
</select>
</div>
</div>


<div class="form-group row" id='form' style="display: none;">

<label for="role_name" class="col-sm-3 col-form-label">Role Name</label> 

<div class="col-sm-6"> 
<input type="text" name="role-name" class="form-control" id="role_name" placeholder="Enter role name" required>
</div>

</div>

<div class="form-group row" id='form1' style="display: none;">
<label for="role_desc" class="col-sm-3 col-form-label">Role Description</label> 

<div class="col-sm-6"> 
<input type="text" name="role-desc" class="form-control" id="role_desc" placeholder="Enter role description" required>
</div>
</div>

</div>

<div class="col-sm-4">

@if($res['empDetails'][0]->pic != null)

<img 

src=  "{{ asset('storage/uploads/staff/'.$res['empDetails'][0]->pic)}}" 

alt="" class="img-fluid mb-3" width="170px" height="170px" style="padding-top: 2%;" id="user_pic_edit" >

@else

<img src="/img/avatar.png" alt="" class="img-fluid mb-3" width="170px" height="170px" style="padding-top: 2%;" id="user_pic_edit" >


@endif

<div class="form-group" id="selectFile">
<input type="file" class="mr-8 form-control-file " name="image" onchange="imagePreview(this.files[0],0)">
</div>
</div>
</div>
</div>
</div>

<div class="col-sm-12">                 
<div class=" text-center">
<br>
<legend>Employee Privilege</legend>
</div>


<div id="prevss" name="prevs">

@foreach($res['rolePrevs'] as $value)


@if($value->id==$res['empDetails'][0]->roleId)



<div class="row">
<div class="form-group row ml-5 pl-5">
<input class="form-check-input" type="checkbox" value="1" id= 'p{{$value->prevId}}' onchange="clicked(this.id,0)" name="{{$value->prevId}}" disabled checked>

<label class="form-check-label" style="color:black" for="label" id='pd{{$value->prevId}}'>{{$value->prevDesc}}</label>

</div>
</div>

@endif

@endforeach

</div>
</div>

<div class="pull-right">
<button type="button" class="btn btn-primary" id="submitFormChanges" data-prevs="{{$res['prevs']}}"  style="border-radius:5px;">Save Changes</button>



<button type="button" class="btn btn-dark text-white" data-dismiss="modal"  style="border-radius:5px;">Cancel</button>

</div>


</form>
</div>

</div>

</div>
</div>

