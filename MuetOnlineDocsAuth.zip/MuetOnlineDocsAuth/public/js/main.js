try {
    theViewer.defaultViewer = new theViewer.Viewer({});
} catch (e) {}