<?php

if($degInfo!=null)
{
$dod = $degInfo->dod;
$dop = $degInfo->dop;
$doe = $degInfo->doe;
$position = $degInfo->position;}

else
{
$dod = "";
$dop = "";
$doe = "";
$position = 0;

}
?>

<form class="form-horizontal" role="form" method="post" action="/student/insert" id="otherInfo">

<?php echo csrf_field(); ?>

<br><br>
<div class="alert alert-danger hidden" id="degreefail"
style="color: white" >
</div>
<input type="hidden" name="id" value="<?php echo e($user->rollNo); ?>">
<legend class="text-center">Other Information Related to Degree/Pass Certificate</legend>
<div class="row">
<div class="col-sm-6">
    <div class="form-group row">
        <label class="col-sm-4 col-form-label">Roll No:</label>
        <div class="col-sm-8">
            <input type="text" name="roll_no:" class="form-control" id="roll_no" placeholder="eg:15SW58" readonly value="<?php echo e(strtoupper($user->rollNo)); ?>">
        </div>
    </div>
    <div class="form-group  row">
        <label class="col-sm-4 col-form-label">Position:</label>
<div class="col-sm-8 ">
<select class="form-control selectpicker" name="position" id="position">
<option value="0">none</option>

<option value="1">1<sup>st</sup></option>
<option value="2">2<sup>nd</sup></option>
<option value="3">3<sup>rd</sup></option>
</select>
    </div>
    </div>
    <div class="form-group  row">
        <label class="col-sm-4 col-form-label">Date of Deceration of result:</label>
        <div class="col-sm-8 ">
    <input class="form-control" type="date" name="dod"  id="dod" value="<?php echo e($dod); ?>">
        </div>
    </div>

</div>
<div class="col-sm-6">
    <div class="form-group row">
        <label class="col-sm-4 col-form-label">CGPA:</label>
        <div class="col-sm-8">
    <input type="number" name="cgpa" class="form-control" 
     value="<?php echo e($cgpa); ?>" readonly id="cgpa">
        </div>
    </div>
    <div class="form-group  row">
        <label class="col-sm-4 col-form-label">Last Exam Held:
       </label>
        <div class="col-sm-8 ">
            <input class="form-control" type="date" name="doe" required id="doe" value="<?php echo e($doe); ?>">
        </div>
    </div>
    <div class="form-group  row">
        <label class="col-sm-4 col-form-label">
            Date of Pasing:
        </label>
        <div class="col-sm-8 ">
            <input class="form-control" type="date" name="dop" required id="dop" value="<?php echo e($dop); ?>">
        </div>
    </div>
</div>
</div>
<div class="row">
<div class="col-sm-12">
    <!-- Cancel button removed from here 5/5/18 -->
    <div class="pull-right">
       <input type="submit" name="submit" class="btn btn-success" value="Save" style="border-radius:5px;">
     <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
    </div>
    <br>
    <br>
</div>
</div>
</form>

<script type="text/javascript">
    document.getElementById('position').value = <?php echo e($position); ?>;
</script>