<!-- view employee details modal -->
<div class="modal fade" id="viewemp" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog  modal-lg" role="document">
<div class="modal-content">
<div class="modal-header bg-info text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Employee Profile - <?php echo e(ucwords($res['empDetails'][0]->name)); ?></h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">
<form class="form-horizontal" role="form" method="post" action="#">
<div class="col-sm-12">
<div>
<div class="card-user">
<div class="author2">
<a href="#">

<?php if($res['empDetails'][0]->pic != null): ?>

<img class="avatar border-gray" 
src=  "<?php echo e(asset('storage/uploads/staff/'.$res['empDetails'][0]->pic)); ?>"

alt="employee picture" id="user_pic">

<?php else: ?>

<img class="avatar border-gray" src="/img/avatar.png" alt="employee picture" id="user_pic">

<?php endif; ?>
</a>
</div>
<div class="Username">
<p style="text-align: center;font-size: 2em;color: black;font-style: bold;font-family: 'Raleway', sans-serif;margin-bottom: 2px" id="headempname">
<?php echo e(ucwords($res['empDetails'][0]->name)); ?>

</p>
<p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px" class="lead" id="heademprole">
<?php echo e(ucwords($res['empDetails'][0]->role)); ?>

</p>

<?php if($status!=null && $status==0): ?>

    <p style="text-align: center;font-size: 1.1em;font-family: 'Raleway', sans-serif;margin-top: 2px;" class="lead">
          <i class="fa fa-circle" style="color:orange"></i> Account Deactivated
    </p>

<?php endif; ?>

</div>
<hr>



<!-- Nav tabs -->
<ul class="nav nav-pills nav-fill customtab2" role="tablist">
<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#aboutE" role="tab"><span><i class="fa fa-user-circle"></i> About me</span></a> </li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#roleE" role="tab"> <span><i class="ti-blackboard"></i> Role</span></a>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#workE" role="tab"> <span><i class="ti-ruler-pencil"></i> Work done</span></a>
</li>
</ul>
<!-- Tab panes -->
<div class="tab-content">
<div class="tab-pane active" id="aboutE" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div>
<div class="contact-information">
<legend>Personal Information</legend>
<div class="phone-content" style="font-family: 'Raleway', sans-serif;" >
<span class="contact-title  ">Staff Id:</span>

<span id="empid">
<?php echo e($res['empDetails'][0]->id); ?>

</span>

</div>
<div class="phone-content">
<span class="contact-title  ">Name:</span>
<span id="empname">
<?php echo e(ucwords($res['empDetails'][0]->name)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Father Name:</span>
<span id="empfname">
<?php echo e(ucwords($res['empDetails'][0]->fatherName)); ?>

</span>

</div>
<div class="phone-content">
<span class="contact-title  ">Date of Birth:</span>
<span id="empdob">
<?php echo e($res['empDetails'][0]->dob); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">CNIC:</span>
<span id="empcnic">
<?php echo e($res['empDetails'][0]->cnic); ?>

</span>
</div>

<div class="gender-content">
<span class="contact-title  ">Gender:</span>
<span id="empgender">
<?php echo e($res['empDetails'][0]->gender== 'm' ? 'Male' : 'Female'); ?> 
</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Address:</span>
<span id="empaddr">

<?php echo e(ucfirst($res['empDetails'][0]->addr)); ?>


</span>
</div>

<legend>Contact Information</legend>
<div class="phone-content">
<span class="contact-title  ">Email(main):</span>
<span id="empemailM">
<?php echo e($res['empDetails'][0]->email); ?>

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Email(other):</span>
<span  id="empemailO">
<?php echo e($res['empDetails'][0]->other); ?>

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Phone:</span>
<span id="empphone">
<?php echo e($res['empDetails'][0]->mbNo); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Interest:</span>
<span id="empinterest">

	<?php echo e($res['empDetails'][0]->interest != null || $res['empDetails'][0]->interest != "" ? ucfirst($res['empDetails'][0]->interest) : '-'); ?>


</span>
</div>

</div>
<div class="basic-information">
<legend>Education</legend>

<div class="phone-content  ">
<span class="contact-title">PEC reg: No:</span>
<span id="emppec">

	<?php echo e($res['empDetails'][0]->pecRegNo == '0' ? '-' : $res['empDetails'][0]->pecRegNo); ?> 

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Qualification:</span>
<span id="empqualification">

<?php echo e($res['empDetails'][0]->qualification != null || $res['empDetails'][0]->qualification != "" ? ucfirst($res['empDetails'][0]->qualification) : '-'); ?> 


</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Publication:</span>
<span id="emppublication">

	<?php echo e($res['empDetails'][0]->publications != null || $res['empDetails'][0]->publications != "" ? ucfirst($res['empDetails'][0]->publications) : '-'); ?>


</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Expertise:</span>
<span id="empexpertise">

	<?php echo e($res['empDetails'][0]->expertise != null || $res['empDetails'][0]->expertise != "" ? ucfirst($res['empDetails'][0]->expertise) : '-'); ?>


</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Designation:</span>
<span id="empdesignation">
<?php echo e(ucfirst($res['empDetails'][0]->designation)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Department:</span>
<span id="empdept">
<?php echo e(ucwords($res['empDetails'][0]->dept)); ?>

</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- tab2 -->
<div class="tab-pane p-20" id="roleE" role="tabpanel">
<div class="row">
<div class="basic-information">

<legend>Role Assigned</legend>

<p style="font-size: 1.5em;font-family: 'Raleway', sans-serif;color: black;" id="emprole">
<?php echo e(ucwords($res['empDetails'][0]->role)); ?>

</p>

<legend>Privileges Assigned</legend>


<div class="phone-content" id="prevassigned" >


<?php $__currentLoopData = $res['rolePrevs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p class='p-20'> <?php echo e(ucfirst($value->prevDesc)); ?></p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>
</div>
</div>
<div class="tab-pane p-20" id="workE" role="tabpanel">



<div class="row">
<div class="col-sm-6">
<div class="card text-center" >
<div class="card-body">
<h5 class="card-title">Employee Accounts Created </h5>
<p class="card-text"><?php echo e($res['crud']['empCr']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Roles Created</h5>
<p class="card-text"><?php echo e($res['crud']['roleCr']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Employee Accounts Updated </h5>
<p class="card-text"><?php echo e($res['crud']['empUp']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Students Updated</h5>
<p class="card-text"><?php echo e($res['crud']['stdUp']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:red;">Employee Accounts Deactivated </h5>
<p class="card-text"><?php echo e($res['crud']['empDel']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:red;">Students Deleted</h5>
<p class="card-text"><?php echo e($res['crud']['stdDel']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:green;">Students Verified</h5>
<p class="card-text"><?php echo e($res['crud']['stdVer']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:orange;">Students Reported</h5>
<p class="card-text"><?php echo e($res['crud']['stdRep']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>


</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
