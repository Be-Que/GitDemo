<!-- Delete Employee MODAL-->
    <div class="modal fade" id="delemp">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h6 class="modal-title text-white" id="addEModalLabel">Are you sure you ?</h6>
                     <button class="close text-white" data-dismiss="modal">
                     <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <?php if($status !=0): ?>

                    <p>Do you really want to deactivate this employee account?</p>

                    <?php else: ?>

                    <p>Do you really want to permanently delete this employee account?</p>

                    <?php endif; ?>

                    <form action="/employees" method="post" id="deleteform">

                        <input type="hidden" name="id" value="<?php echo e($res[0]->id); ?>">
                        <input type="hidden" name="status" value="<?php echo e($status); ?>">

                        <?php echo csrf_field(); ?>

                        <div class="pull-right">                       

                            <button type="button" id="submitdelete" class="btn btn-danger"  style="border-radius:5px;">Delete</button>

                            <button type="button" class="btn btn-dark text-white" data-dismiss="modal"  style="border-radius:5px;">Cancel</button>

                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
