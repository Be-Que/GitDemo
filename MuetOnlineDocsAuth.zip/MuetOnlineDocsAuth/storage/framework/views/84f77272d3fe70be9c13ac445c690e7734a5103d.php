<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <title>Log In - Validator</title>

     
</head>

<body class="web_back_color">

   <div class="nav1" style="margin-top: 150px;"></div>
                     
    <div class="col-md-12 col-md-6 ">
        
        <div class="pos2 form-row">
            
            <img src="/img/logo.png" style="height: 100px;display: inline;">
            <h4 class='text-white' style="margin-top: 30px;display: inline;">  

                <?php echo e(config('app.name')); ?> 

            </h4>              

        </div>

        <div class="col-md-5 " >
            
            <hr width="1" size="200">

            <form action="/dashboard" method="post" class="pos" style="margin-top: -230px;">

                <?php echo csrf_field(); ?> 

                <div class="input-group">

                    <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php if($flash=session('success')): ?>
                        
                        <!-- email sent -->
                        
                        <div class="alert alert-success" role="alert" style="color:white;">
                            
                            <?php echo e($flash); ?>

                        
                        </div>
                                    
                    <?php endif; ?>

                    <?php if($flash=session('unsuccess')): ?>
                        
                        <!-- email sent -->
                        
                        <div class="alert" role="alert" style="color:white;background-color: orange">
                            
                            <?php echo e($flash); ?>

                        
                        </div>
                                    
                    <?php endif; ?>


                </div>

                <div class="input-group" >
                    
                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                    
                    <input type="email" style=" border-radius: 0px;" class="btn btn-outline-secondary btn-block text-white text-left" placeholder="enter your email" name="email" required>
                
                </div>

                <br><br>

                <div class="input-group">
                    
                    <span class="input-group-addon"><i class="fa fa-lock "></i></span>
                    
                    <input  type="password"  name="pass" class="btn btn-outline-secondary btn-block text-white text-left" placeholder="enter your password" required>
                
                </div>

                <br> <br>
                
                <div class="text-center">
                        <button class="col-md-12 login-btn-blue" ><span style="  font-family: 'Raleway', sans-serif;">CONNECT</span></button>
                </div>
                
                <br><br>
                
                <div>
                    
                    <div class="text-center pull-left">
                        
                        <a href="#"  data-toggle="modal" data-target="#ForgotPass"> 
                        
                            <b style="color: #5c719c">Forgot your password?</b>

                        </a>
                        
                    </div>
                </div>
                
            </form>
        </div>
    </div>

    <?php echo $__env->make('modals.forget_password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <script src="/js/jquery.min.js"></script>
        <script src="/js/tether.min.js"></script>
        <script src="/js/bootstrap.min.js"></script>

    </header>
    <script type="text/javascript">
        
        $('#resetPassSubmit').on('click', function(){

            $('#resetPassSubmit').attr('disabled','disabled');

            document.getElementById('forgetPassForm').submit();

        });
    </script>

</body>

</html>