   
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>Verified Students</title>
<style type="text/css">

.table-title {
color: #fff;
background: #4b5366;        
padding: 16px 25px;
margin: -20px -25px 10px;
border-radius: 3px 3px 0 0;
}

.table-title h2 {
margin: 5px 0 0;
font-size: 24px;
}

.table-wrapper {
background: #fff;
padding: 20px 25px;
margin: 30px auto;
border-radius: 3px;
box-shadow: 0 1px 1px rgba(0,0,0,.05);
}

.table-filter .filter-group {
float: right;
margin-left: 15px;
}
.table-filter input, .table-filter select{
height: 34px;
border-radius: 3px;
border-color: #ddd;
box-shadow: none;
}
.table-filter {
padding: 5px 0 15px;
border-bottom: 1px solid #e9e9e9;
margin-bottom: 5px;
}
.table-filter .btn {
height: 34px;
}
.table-filter input, .table-filter select {
display: inline-block;
margin-left: 5px;
}
.table-filter input, .table-filter select {
width: 200px;
display: inline-block;
}
</style>


<script src="/js/jquery-1.10.2.js"></script>
<script src="/js/jquery.mask.js"></script>


</head>

<body>

<?php $__env->startSection('content'); ?>
<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<div class="table-wrapper">
<div class="table-title">
<div class="row">
<div class="col-sm-6">
<h2 class="text-white">Verified <b>Students</b></h2>
</div>

</div>
</div>

<?php if($search): ?>
<div class="table-filter">
<div class="row">

<div class="col-sm-3">

  <label>Sort &nbsp;</label>

  <select class="form-control" style="display: inline-block;width: 120px;"id="orderSelect" onchange="ordSelect()">
      <option id="or-rollno" value="rollno">RollNo</option>
      <option id="or-dept" value="dept">Department</option>
      <option id="or-batch" value="batch">Batch</option>
      <option id="or-system" value="system">System</option>
  </select>



</div>
<div class="col-sm-9">

<form action="/verifiedStudents/search" class="form-inline pull-right" role="form" id="searchform" method="post">

<?php echo csrf_field(); ?>
<div class="filter-group">

<input type="text" class="form-control " placeholder="Search here" name="search" oninput ="searchlist()" 
id="searchInput" list="searchlist" autocomplete="off" >

<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>

<input type="hidden" class="form-control " name="sjson" id="sjson"> 

<datalist id="searchlist">

</datalist>
</div>
</form>
</div>

</div>
</div>
<?php endif; ?>

<?php if(session('message')): ?>

<div class="alert alert-danger" role="alert" style="color:white;">
    
<?php echo e(session('message')); ?>


</div>
<?php endif; ?>


<?php if($flash=session('anyerror')): ?>

<div class="alert alert-danger mt-4 ml-3" role="alert" style="color:white;">
                        
<?php echo e($flash); ?>   
                    
</div>

<?php endif; ?>


<!-- List View for Students-->
<section id="posts">
<div>
<div class="row">

<div class="col">
<div>
<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
<th>Action</th>
</tr>
</thead>
<tbody id="emps">

<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td scope="row"><?php echo e($loop->index+1); ?></td>
<td><?php echo e(ucwords($std->fullname)); ?></td>

<td><?php echo e(strtoupper($std->rollNo)); ?></td>

<td><?php echo e(ucwords($std->name)); ?></td>
<td><?php echo e($std->batch); ?></td>
<td>

<?php if(array_key_exists('certificate',$content)): ?>

<a href="<?php echo e(url('/dashboard/verifiedStudents/certificate?q='.base64_encode($std->rollNo))); ?>"><i class="btn btn-dark fa fa-graduation-cap"   title="Certificate"></i></a>

<?php endif; ?>

<?php if(array_key_exists('view-std',$content)): ?>

<button class="btn btn-info fa fa-info-circle" title="View" 
id="view<?php echo e($std->rollNo); ?>" onclick="viewStd('<?php echo e($std->rollNo); ?>')">
  
</button>

<?php endif; ?>

<?php if(array_key_exists('report-std',$content)): ?>

  <button class="btn btn-danger fa fa-warning" data-toggle="modal" data-target="#ReportModal"  title="report"
  onclick="getId('<?php echo e($std->rollNo); ?>')">
  </button>
<?php endif; ?>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php if($search): ?>

<?php echo e($results->appends(request()->query())->links()); ?>


<?php endif; ?>
</div>

</div>
</div>
</div>
</div>

</section>

</div>
</div>
</div>



<!--  Student Report MODAL 7/8/18-->

<div class="modal fade" id="ReportModal">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header bg-danger text-white">
<h6 class="modal-title text-white" id="addEModalLabel">Report Student</h6>
<button class="close text-white" data-dismiss="modal">
 <span>&times;</span>
</button>
</div>
<div class="modal-body">

<form class="form-horizontal" role="form" method="post" action="/student/report">
<?php echo csrf_field(); ?>

<div class="col-sm-12">
<div class="row">
<div class="col-sm-6">
<div class="form-group">
<div class="row">
    <div class="col-sm-4">
        <input name="pinfo" class="form-control" type="checkbox" value="personalInfo" id="pinfo" 
         onclick="changeCol('pinfo')">
    </div>
    <label for="Name" class="col-sm-8 col-form-label"
    id="rppinfo">Personal Info</label>
</div>
</div>
<div class="form-group">
<div class="row">
    <div class="col-sm-4">
        <input name="transcript" class="form-control" type="checkbox" value="transcript" id="trans"
        onclick="changeCol('trans')"> 
    </div>
    <label for="Name" class="col-sm-8 col-form-label"
    id="rptrans">Transcript Info</label>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<div class="row">
    <div class="col-sm-4">
        <input  class="form-control" type="checkbox" value="degree" name="degree" value="degree" id="degree"
        onclick="changeCol('degree')">
    </div>
    <label for="Name" class="col-sm-8 col-form-label" id="rpdegree">Degree Info</label>
</div>
</div>
<div class="form-group">
<div class="row">
    <div class="col-sm-4">
        <input name="other" class="form-control" type="checkbox" value="other" id="other" onclick="changeCol('other')">
    </div>
    <label for="Name" class="col-sm-8 col-form-label" id="rpother">Other</label>
</div>
</div>
</div>

</div>
<div class="form-group">
<label for="Name" class="col-sm-8 col-form-label">Comment</label>
<div class="col-sm-12">
<textarea name="comment" class="form-control" id="x" placeholder="comments"></textarea>
</div>
</div>

</div>
<div class="pull-right">
<input type="hidden" name="id" id="rollNo" value="">	
 <input type="submit" name="submit" class="btn btn-danger" style="border-radius:5px;" value="Report">

    <button type="button" class="btn btn-dark text-white" data-dismiss="modal"  style="border-radius:5px;">Cancel</button>
</div>
</form>
</div>
</div>
</div>
</div>
<div id="viewModal">
  

</div>
<?php $__env->stopSection(); ?>


 <?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

        loc= new URLSearchParams(window.location.search);
        $('#or-'+loc.get('q')).attr('selected',true);
        
        function ordSelect(){

            window.location = "http://127.0.0.1:8000/dashboard/verifiedStudents?q="+$('#orderSelect').val();

        }
    
 	</script>
  <script type="text/javascript">
document.getElementById('dashboard').classList.remove('active');

document.getElementById('students').classList.remove('active');
document.getElementById('staff').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');


document.getElementById('verstudents').classList.add('active');

  // function for report modal

 	function getId(id){
document.getElementById('rollNo').value = id;
}

function changeCol(id)
{
  if(document.getElementById(id).checked)
    {
      document.getElementById('rp'+id).style="font-weight:bold;color:black;";
    }
  else{

document.getElementById('rp'+id).style="font-weight:normal;color:gray;";

}  
}

// when click on view Button

function viewStd(id)
{
  $('#view'+id).attr('disabled',true);
  $.get('<?php echo e(URL::to("/view")); ?>/'+id,function(data){
     
   $('#viewModal').empty().append(data);
   $('#ViewSModal').modal({backdrop: 'static', keyboard: false});
   $('#view'+id).attr('disabled',false);
  });
}


function searchlist(){
var query = $('#searchInput').val().trim();
if(query.length>1)
{
  $.get('<?php echo e(URL::to("verifiedStudents/search")); ?>?q='+query,function(data){

    
  document.getElementById('searchlist').innerHTML="";
    for(var i=0;i<data.length;i++)
    {
      var resultSet = "Name: "+data[i].fullname+" RollNo: "+data[i].rollNo+" Department: "+data[i].name+" Batch: "+data[i].batch;
      var option = document.createElement('option');
      
      option.value = resultSet;
 var jsonData='[{' +
'"rollNo":"'+data[i].rollNo+
'","fullname":"'+data[i].fullname+
' ","name":"'+data[i].name+
' ", "batch":'+data[i].batch+'}]';



option.title=jsonData;



document.getElementById("searchlist").appendChild(option);
    }

  });
}
}


$("#searchInput").bind('input', function () {
var flag=checkExists( $('#searchInput').val() );
if(flag){

document.getElementById('sjson').value=flag;

window.location.assign("/verifiedStudents/search/results?val="+flag);

}
});

function checkExists(inputValue) {
console.log(inputValue);

var x = document.getElementById("searchlist");
var i;
var flag;
var label;
for (i = 0; i < x.options.length; i++) {
if(inputValue == x.options[i].value){
flag = true;
label=x.options[i].title;
}
}

if(flag){
return label;
}
return flag;
}


 </script>
 <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>