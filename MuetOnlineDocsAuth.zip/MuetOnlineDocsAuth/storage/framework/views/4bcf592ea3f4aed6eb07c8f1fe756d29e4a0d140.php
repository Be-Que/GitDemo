<?php $__env->startComponent('mail::message'); ?>

You told us you forgot your password. If you really did then click on the button below to reset your password

<?php $__env->startComponent( 'mail::button', ['url' => 'http://127.0.0.1:8000/login/resetPassword?_to='.$token ] ); ?>
Choose New Password 
<?php echo $__env->renderComponent(); ?>

If you didn't mean to change your password then ignore this mail and your password won't change 

Thanks,<br>
<?php echo e(config('app.name')); ?> support team
<?php echo $__env->renderComponent(); ?>
