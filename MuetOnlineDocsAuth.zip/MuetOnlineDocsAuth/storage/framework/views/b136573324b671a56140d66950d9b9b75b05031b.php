<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Account - <?php echo e(ucwords($res['empDetails'][0]->name)); ?></title>



    <!-- Styles -->

    <?php $__env->startSection('styles2'); ?>
    <link href="/assets/css/lib/helper.css" rel="stylesheet">
    <?php $__env->stopSection(); ?>

</head>
<body>

    <?php $__env->startSection('content'); ?>

     <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

        <div class="col-md-12 ml-2">
            <div class="card-user">
                
                <div class="author ml-4">
                    <a href="#">

                    	<!-- user image -->

                        <?php if($res['empDetails'][0]->pic != null): ?>

                        <img class="avatar border-gray" 
                        src=  "<?php echo e(asset('storage/uploads/staff/'.$res['empDetails'][0]->pic)); ?>"

                        alt="employee picture" id="user_pic">

                        <?php else: ?>

                        <img class="avatar border-gray" src="/img/avatar.png" alt="employee picture" id="user_pic">

                        <?php endif; ?>
    
                    </a>
                </div>
                <div class="Username">
                    <p style="text-align: center;font-size: 2em;color: black;font-style: bold;text-transform: uppercase;font-family: 'Raleway', sans-serif;margin-bottom: 2px">
                    	<?php echo e(ucwords($res['empDetails'][0]->name)); ?>

                    </p>
                    <p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px" class="lead">
                    	   <?php echo e(ucwords($res['empDetails'][0]->role)); ?>

                    </p>

                    <?php if($status!=null && $status==0): ?>

                    <p style="text-align: center;font-size: 1.1em;font-family: 'Raleway', sans-serif;margin-top: 2px;" class="lead">
                          <i class="fa fa-circle" style="color:orange"></i> Account Deactivated
                    </p>

                    <?php endif; ?>

                </div>
                <hr>

                <!-- Nav tabs -->
                <ul class="nav nav-pills nav-fill customtab2" role="tablist" >
                    <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#about" role="tab"><span><i class="fa fa-user-circle"></i> About me</span></a> </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#role" role="tab"> <span><i class=" ti-blackboard"></i> Privileges</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#work" role="tab"> <span><i class="ti-ruler-pencil"></i> Work done</span></a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="about" role="tabpanel">
                        <div>
                            <div>
                                <div class="tab-content">
                                    <div>
                                        <div class="contact-information">
                                            <legend>Personal Information</legend>
                                            <div class="phone-content" style="font-family: 'Raleway', sans-serif;" >
                                                <span class="contact-title  ">Staff Id:</span>
                                                
                                                <span>
                                                    <?php echo e($id); ?>

                                                </span>

                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Name:</span>
                                                <span ><?php echo e($res['empDetails'][0]->name); ?>

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Father Name:</span>
                                                <span>

                                                    <?php echo e($res['empDetails'][0]->fatherName); ?>

                                                </span>
                                                    
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Date of Birth:</span>
                                                <span>
                                                <?php echo e($res['empDetails'][0]->dob); ?>

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">CNIC:</span>
                                                <span>
                                                    <?php echo e($res['empDetails'][0]->cnic); ?>

                                                </span>
                                            </div>
                                            <div class="gender-content">
                                                <span class="contact-title  ">Gender:</span>
                                                <span>

                                                    <?php echo e($res['empDetails'][0]->gender== 'm' ? 'Male' : 'Female'); ?> 

                                            </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Address:</span>
                                                <span >

                                                   <?php echo e($res['empDetails'][0]->addr); ?>


                                                </span>
                                            </div>

                                            <legend>Contact Information</legend>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Email(main):</span>
                                                <span >
                                                    <?php echo e($res['empDetails'][0]->email); ?>

                                                </span>
                                            </div>

                                             <div class="phone-content">
                                                <span class="contact-title  ">Email(other):</span>
                                                <span >
                                                    <?php echo e($res['empDetails'][0]->other); ?>

                                                </span>
                                            </div>

                                            <div class="phone-content">
                                                <span class="contact-title  ">Phone:</span>
                                                <span>
                                                <?php echo e($res['empDetails'][0]->mbNo); ?>

                                            </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Interest:</span>
                                                <span>
                                                    <?php echo e($res['empDetails'][0]->interest != null || $res['empDetails'][0]->interest != "" ? ucfirst($res['empDetails'][0]->interest) : '-'); ?>

                                            </span>
                                            </div>
                                            
                                        </div>
                                        <div class="basic-information">
                                            <legend>Education</legend>

                                            <div class="phone-content  ">
                                                <span class="contact-title">PEC reg: No:</span>
                                                <span>
                                                   <?php echo e($res['empDetails'][0]->pecRegNo == '0' ? '-' : $res['empDetails'][0]->pecRegNo); ?> 
                                                </span>
                                            </div>

                                            <div class="phone-content">
                                                <span class="contact-title  ">Qualification:</span>
                                                <span >

                                                    
                                                    <?php echo e($res['empDetails'][0]->qualification != null || $res['empDetails'][0]->qualification != "" ? ucfirst($res['empDetails'][0]->qualification) : '-'); ?> 

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Publication:</span>
                                                <span >
                                                    <?php echo e($res['empDetails'][0]->publications != null || $res['empDetails'][0]->publications != "" ? ucfirst($res['empDetails'][0]->publications) : '-'); ?>

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">expertise:</span>
                                                <span >
                                                    <?php echo e($res['empDetails'][0]->expertise != null || $res['empDetails'][0]->expertise != "" ? ucfirst($res['empDetails'][0]->expertise) : '-'); ?>

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">designation:</span>
                                                <span >
                                                    <?php echo e(ucfirst($res['empDetails'][0]->designation)); ?>

                                                </span>
                                            </div>
                                            <div class="phone-content">
                                                <span class="contact-title  ">Department:</span>
                                                <span >
                                                    <?php echo e(ucwords($res['empDetails'][0]->dept)); ?>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- tab2 -->
                    <div class="tab-pane p-20" id="role" role="tabpanel">
                            <div class="row">
                                    <div class="basic-information">

                                         <legend>Role Assigned</legend>

                                        <p style="font-size: 1.5em;font-family: 'Raleway', sans-serif;color: black;">
                                            <?php echo e(ucwords($res['empDetails'][0]->role)); ?>

                                        </p>

                                       <legend>Privileges Assigned</legend>

                                        <?php $__currentLoopData = $res['rolePrevs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="phone-content" >
                                                <p class="lead" style="
                                                font-family: 'Raleway', sans-serif;font-size: 1em">
                                                <?php echo e(ucfirst($val->prevDesc)); ?>

                                                </p>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                            </div>
                    </div>
                    <div class="tab-pane p-20" id="work" role="tabpanel">
                        
                        <div class="row">
                          <div class="col-sm-6">
                            <div class="card text-center" >
                              <div class="card-body">
                                <h5 class="card-title">Employee Accounts Created </h5>
                                <p class="card-text"><?php echo e($res['crud']['empCr']); ?></p>
                                <!-- logs -->
                                <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title">Roles Created</h5>
                                <p class="card-text"><?php echo e($res['crud']['roleCr']); ?></p>
                                <!-- logs -->
                                 <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title">Employee Accounts Updated </h5>
                                <p class="card-text"><?php echo e($res['crud']['empUp']); ?></p>
                                <!-- logs -->
                                <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title">Students Updated</h5>
                                <p class="card-text"><?php echo e($res['crud']['stdUp']); ?></p>
                                <!-- logs -->
                                 <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title" style="color:red;">Employee Accounts Deleted </h5>
                                <p class="card-text"><?php echo e($res['crud']['empDel']); ?></p>
                                <!-- logs -->
                                <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title" style="color:red;">Students Deleted</h5>
                                <p class="card-text"><?php echo e($res['crud']['stdDel']); ?></p>
                                <!-- logs -->
                                 <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title" style="color:green;">Students Verified</h5>
                                <p class="card-text"><?php echo e($res['crud']['stdVer']); ?></p>
                                <!-- logs -->
                                <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="card text-center">
                              <div class="card-body">
                                <h5 class="card-title" style="color:orange;">Students Reported</h5>
                                <p class="card-text"><?php echo e($res['crud']['stdRep']); ?></p>
                                <!-- logs -->
                                 <a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
                              </div>
                            </div>
                          </div>
                        </div>

                    </div>
                </div>


            </div>
        </div>

    </main>

    <?php $__env->stopSection(); ?>

     <?php $__env->startSection('scripts'); ?>
     
<script type="text/javascript">
    $('#notify').hide();
</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script type="text/javascript">
        document.getElementById('dashboard').classList.remove('active');

        document.getElementById('staff').classList.remove('active');
        
        document.getElementById('students').classList.remove('active');
        
        document.getElementById('account_rights').classList.remove('active');
        
        document.getElementById('verstudents').classList.remove('active');
        
        document.getElementById('profile').classList.remove('active');
        
        document.getElementById('log').classList.remove('active');
        
        document.getElementById('setting').classList.remove('active');

    </script>
    <?php $__env->stopSection(); ?>


</body>
</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>