<legend class="text-center">OBE Based System</legend>
<div class="col-sm-12">
<form class="form-horizontal" role="form" method="post" action="#">
    <table class="table table-striped" id="myTable">
        <thead class="thead">
            <tr>
                <th>#</th>
                <th>PLO</th>
                <th>Percentage</th>
                <th>Grade</th>
                <th>Remarks</th>
            </tr>
        </thead>
    <tbody>
<?php $__currentLoopData = $ploRes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $percentage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td scope="row"><?php echo e($loop->index+1); ?></td>
<td>PLO<?php echo e($loop->index+1); ?></td>
<td><?php echo e($percentage); ?></td>

<?php if($percentage>=85 && $percentage<=100): ?>
<td>A+</td>
<td>Excellent</td>
<?php elseif($percentage>=80 && $percentage<=84): ?>
<td>A</td>
<td>Very Good</td>

<?php elseif($percentage>=75 && $percentage<=79): ?>
<td>B+</td>
<td>Good</td>

<?php elseif($percentage>=70 && $percentage<=74): ?>
<td>B</td>
<td>Nice</td>

<?php elseif($percentage>=65 && $percentage<=69): ?>
<td>C</td>
<td>PASS</td>

<?php elseif($percentage>=60 && $percentage<=64): ?>
<td>D</td>
<td>PASS</td>

<?php elseif($percentage>=50 && $percentage<=59): ?>
<td>E</td>
<td>PASS</td>

<?php else: ?>
<td>F</td>
<td>FAIL</td>


<?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<br>
    <div class="row">
        <div class="col-sm-12">
            <div class="pull-right">
                <!-- Cancel button removed from here 5/5/18 -->

<a href="#mydiv">
                <button class="btn btn-danger" style="border-radius:5px;"
                onclick="show()">Request For Change
            </button>
           </a> 
    <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>        
            </div>
            <br>
            <br>
 </div>
    </div>
</form>

</div>

<br>
<div id="mydiv" style="margin-left: 7%;margin-top: 5%; width: 80%;">
</div>