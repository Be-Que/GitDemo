<?php $__env->startComponent('mail::message'); ?>



<?php echo e($msg); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
