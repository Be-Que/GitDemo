  <!-- Transcript Info Start -->
                       
                            
                                <legend class="text-center">CGPA Based System</legend>
                                <br>
                                <!-- changings 22-7-18 -->
                                <ul class="nav nav-tabs nav-fill   customtab2" role="tablist">

                                    <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#first" role="tab"><span> 1st Year</span></a> </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#second" role="tab"> <span>2nd Year</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#third" role="tab"> <span> 3rd Year</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#final" role="tab"> <span> 4th/Final Year</span></a>
                                    </li>


                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="first" role="tabpanel">
                                        <div>
                                            <div>
                                                <div class="tab-content">
                                                    <div class="col-sm-12">
                                                        1st Year
                                                        <form class="form-horizontal" role="form" method="post" action="#">
                                                            <div class="col-sm-4">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-4 col-form-label">Roll No:</label>
                                                                    <div class="col-sm-8">
                                                                        <h4>15SW58</h4>
                                                                        <!-- <input type="text" name="roll_no:" class="form-control" id="roll_no" placeholder="eg:15SW58" disabled> -->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- ROwsss -->
                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group  row">
                                                                        <label class="col-sm-4 col-form-label">Course Name:</label>
                                                                        <div class="col-sm-8 ">
                                                                            <input type="text" class="form-control" disabled>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group  row">
                                                                        <label class="col-sm-4 col-form-label">Max Marks:</label>
                                                                        <div class="col-sm-8 ">
                                                                            <input type="number" class="form-control" required disabled>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group  row">
                                                                        <label class="col-sm-4 col-form-label">Marks Obtained:</label>
                                                                        <div class="col-sm-8 ">
                                                                            <input type="number" class="form-control" required>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div class="pull-right">
                                                                        <button style="border-radius:15px" class="btn mainlogin  text-white"> Submit</button>
                                                                    </div>
                                                                    <br>
                                                                    <br>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- tab2 -->
                                    <div class="tab-pane  p-20" id="second" role="tabpanel">
                                        <div class="col-sm-12">
                                            2nd Year
                                            <form class="form-horizontal" role="form" method="post" action="#">
                                                <div class="col-sm-4">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Roll No:</label>
                                                        <div class="col-sm-8">
                                                            <h4>15SW58</h4>
                                                            <!-- <input type="text" name="roll_no:" class="form-control" id="roll_no" placeholder="eg:15SW58" disabled> -->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- ROwsss -->
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Course Name:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="text" class="form-control" disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Max Marks:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Marks Obtained:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <div class="pull-right">
                                                            <button style="border-radius:15px" class="btn mainlogin  text-white"> Submit</button>
                                                        </div>
                                                        <br>
                                                        <br>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="tab-pane p-20" id="third" role="tabpanel">
                                        <div class="col-sm-12">
                                            3rd Year
                                            <form class="form-horizontal" role="form" method="post" action="#">
                                                <div class="col-sm-4">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Roll No:</label>
                                                        <div class="col-sm-8">
                                                            <h4>15SW58</h4>
                                                            <!-- <input type="text" name="roll_no:" class="form-control" id="roll_no" placeholder="eg:15SW58" disabled> -->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- ROwsss -->
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Course Name:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="text" class="form-control" disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Max Marks:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Marks Obtained:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <div class="pull-right">
                                                            <button style="border-radius:15px" class="btn mainlogin  text-white"> Submit</button>
                                                        </div>
                                                        <br>
                                                        <br>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="tab-pane p-20" id="final" role="tabpanel">
                                        <div class="col-sm-12">
                                            Final Year
                                            <form class="form-horizontal" role="form" method="post" action="#">
                                                <div class="col-sm-4">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Roll No:</label>
                                                        <div class="col-sm-8">
                                                            <h4>15SW58</h4>
                                                            <!-- <input type="text" name="roll_no:" class="form-control" id="roll_no" placeholder="eg:15SW58" disabled> -->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- ROwsss -->
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Course Name:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="text" class="form-control" disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Max Marks:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required disabled>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="form-group  row">
                                                            <label class="col-sm-4 col-form-label">Marks Obtained:</label>
                                                            <div class="col-sm-8 ">
                                                                <input type="number" class="form-control" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <div class="pull-right">
                                                            <button style="border-radius:15px" class="btn mainlogin  text-white"> Submit</button>
                                                        </div>
                                                        <br>
                                                        <br>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>


                                </div>
                       
                            <br>

                        <!-- Transcript Info End -->