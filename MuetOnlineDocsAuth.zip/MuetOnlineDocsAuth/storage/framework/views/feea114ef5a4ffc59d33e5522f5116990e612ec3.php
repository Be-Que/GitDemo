<!-- Forgot password MODAL -->
    <div class="modal fade" id="ForgotPass">
        
        <div class="modal-dialog modal-lm">
            
            <div class="modal-content">
                
                <div class="modal-header text-white web_back_color">

                    <h5 class="modal-title text-white" id="ForgotModal">Forgot Password?</h5>
                    
                    <button class="close text-white" data-dismiss="modal">
                             
                        <span>&times;</span>
                    </button>
                
                </div>
                
                <div class="modal-body">
                    <div class="col-sm-12">
                        
                        <form action="/login/forgetPassword" method="post" id="forgetPassForm">
                            
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <input type="email" name="email" placeholder="enter your email" class="form-control" id="email" required>
                            </div>
                            
                            <div class="text-center">
                                <button style="border-radius:5px;font-weight: normal;" class="btn text-white login-btn-blue" id="resetPassSubmit" type="button" >Reset password</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
