<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Account - <?php echo e(session('staffInfo')[0]->name); ?></title>




<?php $__env->startSection('styles2'); ?>
<link href="/assets/css/lib/helper.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

</head>
<body>



<?php $__env->startSection('content'); ?>

<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<main role="main">

<div class="col-md-12 ml-2">
<div class="card-user">

<div class="author ml-4">
<a href="#">

<!-- user image -->
<img class="avatar border-gray" 

src=

<?php if(session('staffInfo')[0]->pic!=null): ?>
  "<?php echo e(asset('storage/uploads/staff/'
.session('staffInfo')[0]->pic)); ?>"

<?php else: ?>

"/img/avatar.png"

<?php endif; ?>

alt="..." >


</a>
</div>
<div class="Username">
<p style="text-align: center;font-size: 2em;color: black;font-style: bold;font-family: 'Raleway', sans-serif;margin-bottom: 2px">
<?php echo e(ucwords(session('staffInfo')[0]->name)); ?>

</p>
<p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px" class="lead">
<?php echo e(ucwords($res[0]->role)); ?>

</p>
</div>

<!-- Nav tabs -->
<ul class="nav nav-pills nav-fill customtab2" role="tablist">
<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#about" role="tab"><span><i class="fa fa-user-circle"></i> About me</span></a> </li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#role" role="tab"> <span><i class=" ti-blackboard"></i> Previleges</span></a>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#work" role="tab"> <span><i class="ti-ruler-pencil"></i> Work done</span></a>
</li>
</ul>
<!-- Tab panes -->
<div class="tab-content">
<div class="tab-pane active" id="about" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div>
<div class="contact-information">
<legend>Personal Information</legend>
<div class="phone-content" style="font-family: 'Raleway', sans-serif;" >
<span class="contact-title  ">Staff Id:</span>

<span><?php echo e(session('accInfo')[0]->id); ?>

</span>

</div>
<div class="phone-content">
<span class="contact-title  ">Name:</span>
<span ><?php echo e(ucwords(session('staffInfo')[0]->name)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Father Name:</span>
<span>
<?php echo e(ucwords($res[0]->fatherName)); ?>

</span>

</div>
<div class="phone-content">
<span class="contact-title">Date Of Birth:</span>
<span>
<?php echo e($res[0]->dob); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">CNIC:</span>
<span>
<?php echo e($res[0]->cnic); ?>

</span>
</div>

<div class="gender-content">
<span class="contact-title  ">Gender:</span>
<span>

<?php echo e($res[0]-> gender== 'm' ? 'Male' : 'Female'); ?> 


</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Address:</span>
<span >

<?php echo e(ucfirst($res[0]->addr)); ?>.

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Interest:</span>
<span>


<?php echo e($res[0]->interest != null || $res[0]->interest != "" ? ucfirst($res[0]->interest) : '-'); ?>


</span>
</div>

<legend>Contact Information</legend>
<div class="phone-content">
<span class="contact-title  ">Email(main):</span>
<span ><?php echo e(session('accInfo')[0]->email); ?>

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Email(other):</span>
<span >
<?php echo e($res[0]->email); ?>

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Phone:</span>
<span>
<?php echo e($res[0]->mbNo); ?>

</span>
</div>

</div>
<div class="basic-information">
<legend>Education</legend>

<div class="phone-content  ">
<span class="contact-title">PEC reg: No:</span>
<span>

<?php echo e($res[0]->pecRegNo == '0' ? '-' : $res[0]->pecRegNo); ?> 

</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Qualification:</span>
<span >

<?php echo e($res[0]->qualification != null || $res[0]->qualification != "" ? ucfirst($res[0]->qualification) : '-'); ?> 

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Publication:</span>
<span >

<?php echo e($res[0]->publications != null || $res[0]->publications != "" ? ucfirst($res[0]->publications) : '-'); ?>



</span>
</div>
<div class="phone-content">
<span class="contact-title  ">expertise:</span>
<span >

<?php echo e($res[0]->expertise != null || $res[0]->expertise != "" ? ucfirst($res[0]->expertise) : '-'); ?>


</span>
</div>
<div class="phone-content">
<span class="contact-title  ">designation:</span>
<span >
<?php echo e(ucfirst($res[0]->designation)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title  ">Department:</span>
<span >
<?php echo e(ucwords($res[0]->dept)); ?>

</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- tab2 -->
<div class="tab-pane p-20" id="role" role="tabpanel">
<div class="row">
<div class="basic-information">

<legend>Role Assigned</legend>

<p style="font-size: 1.5em;font-family: 'Raleway', sans-serif;color: black;">
<?php echo e(ucwords($res[0]->role)); ?>

</p>

<legend>Privileges Assigned</legend>

<?php $__currentLoopData = $res2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="phone-content" >
<p class="p-1">
<?php echo e(ucfirst($val->prevDesc)); ?>

</p>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
<div class="tab-pane p-20" id="work" role="tabpanel">

<div class="card" >
<div class="card-body">
<h4 class="card-title"></h4>
<canvas style="margin-left: 10px;align-items: center;" id="myChart" width="1200" height="400">
</div>
</div>
<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" >Employee Accounts Created </h5>
<p class="card-text"><?php echo e($crud['empCr']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Roles Created</h5>
<p class="card-text"><?php echo e($crud['roleCr']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Employee Accounts Updated </h5>
<p class="card-text"><?php echo e($crud['empUp']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Students Updated</h5>
<p class="card-text"><?php echo e($crud['stdUp']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:red;">Employee Accounts Deactivated</h5>
<p class="card-text"><?php echo e($crud['empDel']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:red;">Students Deleted</h5>
<p class="card-text"><?php echo e($crud['stdDel']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:green;">Students Verified</h5>
<p class="card-text"><?php echo e($crud['stdVer']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title" style="color:orange;">Students Reported</h5>
<p class="card-text"><?php echo e($crud['stdRep']); ?></p>
<!-- logs -->
<a href="/dashboard/log?q=chMadeByMe" class="btn btn-primary">More Details</a>
</div>
</div>
</div>
</div>

</div>
</div>


</div>
</div>

</main>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#notify').hide();
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>

<script type="text/javascript">


document.getElementById('dashboard').classList.remove('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.add('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');

</script>

<script type="text/javascript">
var ctx = document.getElementById("myChart");
var myBarChart = new Chart(ctx, {
type: 'bar',
data: {
labels: ["Emp created", "Emp updated","Emp deactivated", "Std updated","Std verified","Std reported","Std deleted","Roles created"],
datasets: [{

data: [<?php echo e($crud['empCr']); ?>,<?php echo e($crud['empUp']); ?>, <?php echo e($crud['empDel']); ?>, <?php echo e($crud['stdUp']); ?>, <?php echo e($crud['stdVer']); ?>, <?php echo e($crud['stdRep']); ?>, <?php echo e($crud['stdDel']); ?>, <?php echo e($crud['roleCr']); ?>], 

backgroundColor: ['#007bff','#007bff','#d2350d','#007bff','#0aa814','#f0b321','#d2350d',"#007bff"],

borderColor: ['#007bff','#007bff','#d2350d','#007bff','#0aa814','#f0b321','#d2350d',"#007bff"],

borderWidth: 4,

pointBackgroundColor: '#007bff'

}]
},
options: {
scales: {
yAxes: [{
ticks: {
beginAtZero: true
}
}]
},
legend: {
display: false,
}
}
});
</script>
<?php $__env->stopSection(); ?>


</body>
</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>