<?php $__env->startSection('styles2'); ?>

	<link rel="stylesheet" type="text/css" href="/css/styles2.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="content-wrap">
	<div class="main">
	    <div class="container-fluid">
	        <main role="main">

	        	<table class="marksSheet">
					<thead>
					  <tr>
					  	<th rowspan="6" class="year marksSheetRows" style="text-align: left;">Year</th>
					    
					  	<th rowspan="3" class="sems marksSheetRows" style="text-align: left;">SemS</th>
					    <th class="subj marksSheetRows" style="text-align: left;">Subject</th>
					    <th class="maxM marksSheetRows" style="text-align: left;">Max Marks</th>
					    <th class="minM marksSheetRows" style="text-align: left;">Min Marks</th>
					    <th class="mObt marksSheetRows" style="text-align: left;">Marks obtained</th>
					    <th class="grade marksSheetRows" style="text-align: left;">Grade</th>
					    <th class="chr marksSheetRows" style="text-align: left;">Credit hour</th>
					    <th rowspan="3" class="gpa marksSheetRows"  style="text-align: left;">g.p.a</th>

					    <th rowspan="6" class="cgpa marksSheetRows" style="text-align: left;">C.g.p.a</th>

					  </tr>
					</thead>
					<tbody >

					  <tr >
					  	<td rowspan="6" class="marksSheetRows" style="text-align: left;">1st</td>
					  	<td rowspan="3" class="marksSheetRows" style="text-align: left;">1st</td>
					   	<td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td rowspan="3"  style="text-align: left;" class="marksSheetRows">3.98</td>
					    <td rowspan="6"  style="text-align: left;" class="marksSheetRows">3.98</td>
					  </tr>
					  
					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					 <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					  <tr >
					  	<td rowspan="3"  style="text-align: left;" class="marksSheetRows">2nd</td>
					   	<td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td rowspan="3"  style="text-align: left;" class="marksSheetRows">4.00</td>
				
					  </tr>
					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					  <!-- end of year -->

					  <!-- second year -->
					 <tr >
					  	<td rowspan="6" class="marksSheetRows" style="text-align: left;">1st</td>
					  	<td rowspan="3" class="marksSheetRows" style="text-align: left;">1st</td>
					   	<td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td rowspan="3"  style="text-align: left;" class="marksSheetRows">3.98</td>
					    <td rowspan="6"  style="text-align: left;" class="marksSheetRows">3.98</td>
					  </tr>
					  
					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					 <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					  <tr >
					  	<td rowspan="3"  style="text-align: left;" class="marksSheetRows">2nd</td>
					   	<td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td rowspan="3"  style="text-align: left;" class="marksSheetRows">4.00</td>
				
					  </tr>
					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>

					  <tr style="text-align: left;">
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">$100</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					    <td style="text-align: left;" class="marksSheetRows">January</td>
					  </tr>
					</tbody>
					</table>
	        </main>
	    </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>