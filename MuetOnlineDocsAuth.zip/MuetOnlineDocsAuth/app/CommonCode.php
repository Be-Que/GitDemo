<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class CommonCode extends Model
{
    public static function getBatchDept($id)
    {
	  $res = DB::table('stdinfo')
		    ->join('batch','stdinfo.doa','=','batch.year')
		    ->select('batch.batch','stdinfo.deptId')
		    ->where('stdinfo.rollNo','=',$id)
		    ->first();
     return $res;		    
    }

    public static function totalSems($deptId,$batch)
    {
       $semester    =  DB::table('courses')
                      ->join('credit_mode','courses.courseCode','=','credit_mode.courseCode')
                       ->distinct('credit_mode.sems')
                       ->select('credit_mode.sems')
                       ->where([
                      ['courses.deptId','=',$deptId],
                      ['credit_mode.batch','=',$batch]
                      ])
                     ->get();
      return $semester;             
    }

   // get Student Status
   
   public static function getStatus($id)
   {

  $prevStatus =   DB::table('stdinfo')->where('rollNo',$id)
                ->select('status')->first();

    return $prevStatus->status;            
   } 
}
