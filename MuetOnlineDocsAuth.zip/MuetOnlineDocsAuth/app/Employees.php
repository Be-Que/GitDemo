<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Employees extends Model
{

    //checked
    public static function getFewEmployees(){

        $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->join('dept','staff.deptid','=','dept.id')

            ->join('role','role.id','=','empaccountsinfo.role')

            ->select('empaccountsinfo.email','staff.id','staff.name','dept.name as dept','role.name as role')

            ->where(['empaccountsinfo.status'=>1,'staff.status'=>1])

            ->where('empaccountsinfo.staffid','!=',session('accInfo')[0]->id)

            ->orderBy('empaccountsinfo.created_at','desc')
            
            ->limit(5)

            ->get();

        return $res;
            
    }

    //checked
    public static function scopeEmpRole($query,$role){

        $res=DB::table('empaccountsinfo')->select('role')

                ->where(['staffid'=> $role['id'], 'status' => 1])

                ->get();

        if(count($res)>0){
            
            return $res[0]->role;

        }else{

            return 0;

        }
    }

    //checked
    public static function scopeEmployees($query, $employees){

        if(session('accInfo')[0]->role==1){

            $res=DB::table('empaccountsinfo')

                ->join('staff','empaccountsinfo.staffid','=','staff.id')

                ->join('dept','staff.deptid','=','dept.id')

                ->join('role','role.id','=','empaccountsinfo.role')

                ->select('empaccountsinfo.email','empaccountsinfo.status','staff.id','staff.name','dept.name as dept','role.name as role')

                ->where('staff.status' ,'=',1)

                ->where('empaccountsinfo.staffid','!=',session('accInfo')[0]->id)

                ->where('empaccountsinfo.status','!=',-1)

                ->orderBy($employees['q'])

                ->paginate(10);
        }else{

            $res=DB::table('empaccountsinfo')

                ->join('staff','empaccountsinfo.staffid','=','staff.id')

                ->join('dept','staff.deptid','=','dept.id')

                ->join('role','role.id','=','empaccountsinfo.role')

                ->select('empaccountsinfo.email','empaccountsinfo.status','staff.id','staff.name','dept.name as dept','role.name as role')

                ->where('staff.status' ,'=',1)

                ->where('empaccountsinfo.staffid','!=',session('accInfo')[0]->id)

                ->where('empaccountsinfo.status','=',1)

                ->orderBy($employees['q'])

                ->paginate(10);

        }

        return $res;
        
            
    }

    public static function scopeEmployeesFilt($query, $employees){

        if($employees['status']=='activated'){

            $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->join('dept','staff.deptid','=','dept.id')

            ->join('role','role.id','=','empaccountsinfo.role')

            ->select('empaccountsinfo.email','empaccountsinfo.status','staff.id','staff.name','dept.name as dept','role.name as role')

            ->where('staff.status' ,'=',1)

            ->where('empaccountsinfo.staffid','!=',session('accInfo')[0]->id)

            ->where('empaccountsinfo.status','=',1)

            ->orderBy('empaccountsinfo.staffid')

            ->paginate(10);

        }else{

            $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->join('dept','staff.deptid','=','dept.id')

            ->join('role','role.id','=','empaccountsinfo.role')

            ->select('empaccountsinfo.email','empaccountsinfo.status','staff.id','staff.name','dept.name as dept','role.name as role')

            ->where('staff.status' ,'=',1)

            ->where('empaccountsinfo.staffid','!=',session('accInfo')[0]->id)

            ->where('empaccountsinfo.status','=',0)

            ->orderBy('empaccountsinfo.staffid')

            ->paginate(10);

        }

        return $res;
        
            
    }

    //checked
    public static function scopeRoleName($query,$roleName){

        //checking role
        $role=DB::table('role')->select('name')

                ->where('id','=', $roleName['role'])

                ->get();

        return $role[0]->name;

    }



    // checked
    public static function scopeExistByEmail($query,$exist){

        // if this email is available or not

        $res=DB::table('empaccountsinfo')->select('staffid')

                ->where(['email'=>$exist['email']])

                ->where('status','!=',-1)

                ->get();

        if(count($res)==1){
            
            $res2=DB::table('staff')->select('status')

                    ->where(['id'=>$res[0]->staffid,'status'=>1])

                    ->get();

            if (count($res2)==1) {
                
                return true;
            
            }

            return false;
        }

        return false;
    } 

    //checked
    public static function scopeExistId($query,$exist){

        $res=DB::table('empaccountsinfo')->select('staffid')
                
                ->where(['staffid'=>$exist['id']])

                ->where('status','!=',-1)

                ->get();

        if(count($res)>0){
            return true;
        }else{

            $res=DB::table('staff')->select('status')

                    ->where(['id'=>$exist['id'],'status'=>1])

                    ->get();

            if(count($res)>0){

                return false;

            }else{
                
                return true;
            }
        }
    }

    //checked
    public static function scopeExistEmpId($query,$exist){
        
        $res=DB::table('empaccountsinfo')

                ->join('staff','empaccountsinfo.staffid','=','staff.id')

                ->select('empaccountsinfo.staffid as id','staff.name')

                ->where(['empaccountsinfo.staffid'=>$exist['id'],'staff.status'=>1])

                ->where('empaccountsinfo.status','!=',-1)

                ->get();

        return $res;

    }

    //checked
    public static function scopeDeleteEmp($query, $deleteEmp){

        $res=DB::table('empaccountsinfo')->where(['staffid' => $deleteEmp['id'],'status' => 1])->update([ 'status'=>0 ]);

        if ($res==1) {
            
            return true;

        }

        return false;

    }

    //checked
    public static function scopePerDelEmp($query, $deleteEmp){

        $res=DB::table('empaccountsinfo')->where(['staffid' => $deleteEmp['id'],'status' => 0])->update([ 'status'=> -1 ]);

        if ($res==1) {
            
            return true;

        }

        return false;

    }

    //checked
    public static function scopeGetData($query,$data){

        $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->join('dept','staff.deptid','=','dept.id')

            ->join('role','empaccountsinfo.role','=','role.id')

            ->select('empaccountsinfo.email','staff.id','staff.pic','staff.name','role.name as role','empaccountsinfo.status','role.id as roleId')

            ->where(['empaccountsinfo.staffid'=>$data['id'],'empaccountsinfo.status'=>1])

            ->get();

        return $res;
    }


    //checked
    public static function scopeGetDataLogs($query,$data){
        
        $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->join('dept','staff.deptid','=','dept.id')

            ->join('role','empaccountsinfo.role','=','role.id')

            ->select('empaccountsinfo.email','staff.id','staff.pic','staff.name','role.name as role','empaccountsinfo.status','role.id as roleId')

            ->where(['empaccountsinfo.staffid'=>$data['id'],'empaccountsinfo.status'=>1])

            ->get();

        if(count($res)==0){

            //only for logss

            $res=DB::table('empaccountsinfo')

                    ->join('staff','empaccountsinfo.staffid','=','staff.id')

                    ->join('dept','staff.deptid','=','dept.id')

                    ->join('role','empaccountsinfo.role','=','role.id')

                    ->select('staff.id','staff.name','empaccountsinfo.status','role.name as role')

                    ->where(['empaccountsinfo.staffid'=>$data['id']])

                    ->where('empaccountsinfo.status','!=',-1)

                    ->get();

            if(count($res)==0){

                $res=DB::table('empaccountsinfo')

                    ->join('staff','empaccountsinfo.staffid','=','staff.id')

                    ->join('dept','staff.deptid','=','dept.id')

                    ->join('role','empaccountsinfo.role','=','role.id')

                    ->select('staff.id','staff.name','empaccountsinfo.status','role.name as role')

                    ->where(['empaccountsinfo.staffid'=>$data['id']])

                    ->get();
            }

        }
      
        return $res;
    }


    //checked
    public static function scopeGetDetData($query,$data){

        if($data['status']!=null && $data['status']==0){

            // status will be 0 and employee is deactivated

            //getting detailed data
            $res2= DB::table('staff')

                ->join('dept','staff.deptid','=','dept.id')

                ->join('empaccountsinfo','empaccountsinfo.staffid','=','staff.id')

                ->join('role','empaccountsinfo.role','=','role.id')

                ->select('staff.name','staff.surname','staff.fatherName','staff.dob','staff.cnic','staff.addr','staff.email as other','empaccountsinfo.email as email','staff.mbNo','staff.designation','staff.qualification','staff.publications','staff.expertise','staff.interest','staff.gender','staff.pecRegNo','dept.name as dept','role.name as role','role.id as roleId','staff.pic','staff.id')

                ->where(['staff.id'=> $data['id'],'empaccountsinfo.status'=>0,'staff.status'=>1])
                        
                ->get();

            return $res2;

        }

        //getting detailed data
         $res2= DB::table('staff')

                ->join('dept','staff.deptid','=','dept.id')

                ->join('empaccountsinfo','empaccountsinfo.staffid','=','staff.id')

                ->join('role','empaccountsinfo.role','=','role.id')

                ->select('staff.name','staff.surname','staff.fatherName','staff.dob','staff.cnic','staff.addr','staff.email as other','empaccountsinfo.email as email','staff.mbNo','staff.designation','staff.qualification','staff.publications','staff.expertise','staff.interest','staff.gender','staff.pecRegNo','dept.name as dept','role.name as role','role.id as roleId','staff.pic','staff.id')

                ->where(['staff.id'=> $data['id'],'empaccountsinfo.status'=>1,'staff.status'=>1])
                        
                ->get();

        return $res2;
    }

    //checked

    public static function scopePic($query, $pic){
        
        $res=DB::table('staff')->select('pic')->where('id',$pic['id'])->get();

        if(count($res)>0){

            return $res[0]->pic;

        }else{

            return null;
        }
        
    }

    //checked

    public static function scopeSetPic($query,$setPic){

        $res=DB::table('staff')->where(['id' => $setPic['id'],'status' => 1])->update(['pic' => $setPic['pic']]);

        return $res;
    }

    //checked
    public static function scopeUpdateEmail($query,$updateEmail){

        //checking if this email already exists or not
        $exist=Employees::existByEmail(['email'=> $updateEmail['email']]);


        if (!$exist) {
            
            $res=DB::table('empaccountsinfo')->where(['staffid' => $updateEmail['id'],'status' => 1])->update(['email' => $updateEmail['email']]);

            return $res;

        }else{
            return '-1';
        }

    }

    //checked
    public static function scopeUpdatePass($query,$updatePass){

        $res=DB::table('empaccountsinfo')->where(['staffid' => $updatePass['id'],'status' => 1])->update(['pass' => bcrypt($updatePass['pass'])]);

        return $res;

    }

    //checked
    public static function scopePassByEmail($query,$pass){

        $res=DB::table('empaccountsinfo')->select('pass','staffid')->where(['email'=>$pass['email'],'status'=>1])->get();

        return $res;

    }

    public static function scopeEmail($query,$data){

        $res=DB::table('empaccountsinfo')->select('email')->where(['staffid'=>$data['id'],'status'=>1])->get();

        return $res;

    }

    //checked
    public static function scopePassById($query,$pass){

        $res=DB::table('empaccountsinfo')->select('pass')->where(['staffid'=>$pass['id'],'status'=>1])->get();

        return $res;

    }
    public static function scopeUpdateRole($query,$role){
        
        $res= DB::table('empaccountsinfo')
                
                ->where(['staffid' => $role['id'],'status' => 1])
                
                ->update(['role' => $role['role']]);   

        return $res;
    }

    //checked
    public static function scopeEmpCreate($query,$data){

        $res=DB::table('empaccountsinfo')->insert([
            
            'staffid' => $data['id'],
            'email' => $data['email'],
            'pass' => bcrypt($data['pass']),
            'role' => $data['role'],
            'status' => 1

        ]);

        return $res;
    }

    public static function scopeEmpName($query,$data){

        $res=DB::table('staff')->select('name')
                ->where('id','=',$data['id'])
                ->where('status','=',1)
                ->get();

        return $res[0]->name;

    }

    public static function scopeEmpActivate($query,$data){

       $res=DB::table('empaccountsinfo')
                
                ->where(['staffid' => $data['id'],'status' => 0])
                
                ->update(['status' => 1]); 

        return $res;

    }

    public static function scopeActiveEmail($query,$data){

        $res=DB::table('empaccountsinfo') 

                ->select('status')
                
                ->where(['email' => $data['email'],'status' => 1])

                ->get();

        if(count($res)==1){
            
            return true;

        }

        return false;

    }

}
