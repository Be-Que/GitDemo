<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Prevs extends Model
{
    //checked
    public static function prevs(){
    	
    	$res=DB::table('role_prev')
    			
                ->join('privilege','role_prev.prevId','=','privilege.id')
    			
                ->select('privilege.prevDesc','privilege.id as prevId','role_prev.id')
    			
                ->get();

    	return $res;
    }

    //checked
    public static function getAllPrevs(){
        
        $res=DB::table('privilege')
                ->select('privilege.prevDesc','privilege.id')
                ->get();

        return $res;
    }


    // checked
    public static function scopeRolePrevs($query,$rolePrevs){
        
        $res=DB::table('role_prev')
            
            ->join('privilege','privilege.id','=','role_prev.prevId')
            
            ->select('privilege.prevDesc','privilege.id')

            ->where('role_prev.id','=',$rolePrevs['id'])

            ->get();

        return $res;

    }

    //checked
    public static function scopeAssignRolePrev($query,$role_prev){
        
        foreach ($role_prev['roleprevs'] as  $value) {

            $res=DB::table('role_prev')->insert([

                'id' => $role_prev['id'],
                'prevId' => $value

            ]);
        }

        return $res;

    }
}
