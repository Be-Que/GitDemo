<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Hash;

class Login extends Model
{

    // checked
   public static function scopeAuth($query,$auth){
        
        // getting various columns if the account exists

        $res=DB::table('empaccountsinfo')
                
            ->select('email','pass','role','status','staffid as id')
            
            ->where(['email'=>$auth['email'],'status'=> 1])
            
            ->get();

        if(count($res)==1){

            //checking password

            if(Hash::check($auth['pass'],$res[0]->pass)){

                //getting the staff info from staff id in the empaccountsinfo

                $res2= DB::table('staff')

                        ->select('name','pic','status as staffstat')

                        ->where('id','=',$res[0]->id)
                        
                        ->get();


                if ($res2[0]->staffstat==0) {

                    DB::table('empaccountsinfo')
                        
                        ->where('staffid',$res[0]->id )
                        
                        ->update(['status' => 0]);
                    
                    return false;
                }

                session()->flush();

                // saving the staff info and account info

                session(['staffInfo' => $res2]);
                
                session(['accInfo' => $res]); 

                //authenticated

                return true;

            }else{

                // pass do not match auth failed
                
                return false;

            }

        }else{

            // no such email or the status is 0
            
            return false;
        }
    }

    //checked
    public static function getData(){

         $res2= DB::table('staff')

                ->join('dept','staff.deptid','=','dept.id')

                ->join('empaccountsinfo','empaccountsinfo.staffid','=','staff.id')

                ->join('role','empaccountsinfo.role','=','role.id')

                ->select('staff.surname','staff.fatherName','staff.dob','staff.cnic','staff.addr','staff.email','staff.mbNo','staff.designation','staff.qualification','staff.publications','staff.expertise','staff.interest','staff.gender','staff.pecRegNo','dept.name as dept','role.name as role','role.id as roleId')

                ->where('staff.id','=',session('accInfo')[0]->id)

                ->where('empaccountsinfo.status','=',1)
                        
                ->get();

        return $res2;
    }
}
