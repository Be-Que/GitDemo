<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Employees;
use Hash;

class Profile extends Model
{
    //put here all functionalities related to account....

    public function scopePrev($query, $prev){

        $prevs=DB::table('role_prev')->select('prevId')->where('id','=', $prev['role'])->get();

        $content='';
        
        foreach($prevs as $prev){
            
            if($prev->prevId ==14){
                
                $content.=" graph ";

            }

            if($prev->prevId ==13){

                $content.=" emplist ";
                
            }
        
        }

        return $content;

    }


    public static function scopeResetPass($query,$resetPass){

        if($resetPass['email']!=null){

            //updating password

            $res=DB::table('empaccountsinfo')
                    ->where(['email'  => $resetPass['email'],'status'=> 1])
                    ->update(['pass'=> bcrypt($resetPass['new']) ]);


            if($res==1){

                $res=DB::table('empaccountsinfo')
                
                        ->select('email','role','status','staffid as id')
            
                        ->where(['email'=> $resetPass['email'],'status'=> 1])
            
                        ->limit(1)->get();

                $res2= DB::table('staff')

                        ->select('name','pic','status as staffstat')

                        ->where('id','=',$res[0]->id)

                        ->limit(1)
                        
                        ->get();


                // saving the staff info and account info

                session(['staffInfo' => $res2]);
                
                session(['accInfo' => $res]); 

                return true;

            }else{

               return false;

            }

        }else{

           return false;

        }

    }

    // checked
    public static function accountExpireCheck(){
       
       $res=DB::table('empaccountsinfo')

            ->join('staff','empaccountsinfo.staffid','=','staff.id')

            ->where(['staff.id'=> session('accInfo')[0]->id,'empaccountsinfo.status'=>1, 'staff.status'=>1 ])

            ->select('staff.id')

            ->get();

        return $res;    
    }

}
