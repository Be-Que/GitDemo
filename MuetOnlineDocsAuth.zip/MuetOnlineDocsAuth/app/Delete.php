<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\CRUD;
use DB;

class Delete extends Model
{
    // delete student
    public static function deleteStd($id,$prVal){
  
    try {
      
       DB::transaction(function() use($id,$prVal)
       {

              
      DB::table('stdinfo')->where('rollNo',$id)
          ->update(['status' => -1]);
        
  

        // second entry in crud
          
          DB::table('crud')->insert([
    
       'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=>'status',
        'chVal'=>  -1,
        'prevVal'=> $prVal,
        'tableName'=> 'stdinfo',
        'status'=> 0
          ]);

        // third entry in notification table

         DB::table('notification')->insert([
       
        'type'   =>  0,
        'status' => -1,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'status',
       
       ]);
       

       });
    
    } // end of try

     catch (Exception $e) {
      return FALSE;
    }

  return TRUE;
       } // end of method
      
  
// permanent delete student
public static function permanDel($id,$prevStatus)
{
  try {
    DB::transaction(function() use($id,$prevStatus)
    {
    
 DB::table('stdinfo')->where('rollNo',$id)
          ->update(['status' => -3]);
        
  
       // second entry in crud
          
          DB::table('crud')->insert([
    
       'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=>'status',
        'chVal'=>  -3,
        'prevVal'=> $prevStatus,
        'tableName'=> 'stdinfo',
        'status'=> 0
          ]);

        // third entry in notification table

         DB::table('notification')->insert([
       
        'type'   =>  0,
        'status' => -3,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'status',
       
       ]);


    });
    
  } catch (Exception $e) {
    return FALSE;
  }
  return TRUE;
}


public static function report($id,$comment)
{
  try {
      DB::transaction(function() use($id,$comment)

      {
      // first change the status of student

     DB::table('stdinfo')->where('rollNo',$id)
             ->update(['status'=> -2]);
        
      // now update status column in documents table
      DB::table('documents')->where('rollNo',$id)
       ->update(['status' => 0]);

       // now entry in crud table for stdinfo table

       DB::table('crud')->insert([
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=>'status',
        'chVal'  => -2,
        'prevVal'=> 0,
     'tableName' => 'stdinfo',
        'status' => 0

       ]); 

   
       // now entry in notification table

        DB::table('notification')->insert([
      
        'type'   => 0,
        'status' => -2,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'comment'=> $comment
       ]);
});  
  

  } // end of try 

  catch (Exception $e) {
    return FALSE;
  }

 return TRUE;

} // end of function

// restore student

public static function restore($id)
{
     $res  =     DB::table('crud')->select('prevVal')
            ->where([
            ['id',$id],
            ['tableName','stdinfo']
            ])
             ->orderBy('created_at','dsc')
                     ->first();

      $status = $res->prevVal;
    try {
   
      DB::transaction(function() use($id,$status)
      {
      DB::table('stdinfo')->where('rollNo',$id)
      ->update(['status' => $status]);

      // insert in crud table

        DB::table('crud')->insert([
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=>'status',
        'chVal'  => $status,
        'prevVal'=> -1,
     'tableName' => 'stdinfo',
        'status' => 0

       ]); 

   
       // now entry in notification table

        DB::table('notification')->insert([
      
        'type'   => 0,
        'status' => -1,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id
       ]);

      });

     } catch (Exception $e) {
     return FALSE;
   }

   return TRUE;
}


}// end of model
