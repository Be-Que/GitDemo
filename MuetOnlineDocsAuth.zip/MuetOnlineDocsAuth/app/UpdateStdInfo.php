<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class UpdateStdInfo extends Model
{
     // student personal info
    public static function updateRecord($id,$changefield,$oldfield,$description)
    {  $loop = 0;
     try {

      DB::transaction(function () use($id,$changefield,$oldfield,$loop,$description)
      { // update record
      
      DB::table('stdinfo')->where('rollNo',$id)
      ->update($changefield);

       // second entry in crud table
      
       foreach ($changefield as $key => $value) {
        // here first check the lables
        if($description[$loop]==$key)
        {
          $desp = "";
        }
        else
        {
          $desp = '('.$description[$loop].')';
        }

        DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=>$key.$desp,
        'chVal'=> $value,
        'prevVal'=> $oldfield[$loop],
        'tableName'=> 'stdinfo',
        'status'=> 0 
        ]);

        // now third entry in notification table 
      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> $key.$desp,
        
       ]);
        
        $loop++;
       }
      
});

} // end of try

 catch (Exception $e) {
       return FALSE;
     }
       
      return TRUE;
    
 } // end of method

    

}// end of model
