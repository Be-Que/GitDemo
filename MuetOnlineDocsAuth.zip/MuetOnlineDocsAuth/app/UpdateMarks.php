<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;


class UpdateMarks extends Model
{
    public static function updateThMarks($id,$courseIdTh,$marksTh,$changeTH,$oldchangeTH)
    {
      try {
        DB::transaction(function () use($id,$courseIdTh,$marksTh,$changeTH,$oldchangeTH)
        {
        
       for($i=0;$i<count($marksTh);$i++)
       
       {     
       DB::table('stdexaminfo')->where([
            ['rollNo','=',$id],
            ['courseId','=',$courseIdTh[$i]]
        ])->update(['markObtInTh'=> $marksTh[$i]]);      
    
    }  // end of loop
  
      // second entry in crud table

     foreach($changeTH as $key => $value)
    {
      DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'markObtInTh',
        'chVal'=> $value,
        'prevVal'=> $oldchangeTH[$key],
        'tableName'=> 'stdexaminfo',
        'status'=> 0 ,
        'comment'=>$courseIdTh[$key]
      ]);
    
     // third entry in notification table
      DB::table('notification')->insert([
       
        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id, 
        'colName'=> 'markObtInTh',
        'comment'=> $courseIdTh[$key]
       ]);
    } // end of loop
   
    }); // end of DB 
    }  // end of try

      catch (Exception $e) {
        return FALSE;
      }
        
  return TRUE;
 } // end of function


   public static function updatePrMarks($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR)
    {
      try {
        DB::transaction(function () use($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR)
        {
        
       for($i=0;$i<count($marksobtPR);$i++)
       
       {     
       DB::table('stdexaminfo')->where([
            ['rollNo','=',$id],
            ['courseId','=',$courseIdPR[$i]]
        ])->update(['markObtInPr'=> $marksobtPR[$i]]);      
    
    }  // end of loop
  
      // second entry in crud table

     foreach($changePR as $key => $value)
    {
      DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'markObtInPr',
        'chVal'=> $value,
        'prevVal'=> $oldchangePR[$key],
        'tableName'=> 'stdexaminfo',
        'status'=> 0 ,
        'comment'=>$courseIdPR[$key]
      ]);
    
     // third entry in notification table
    
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'markObtInPr',
        'comment'=> $courseIdPR[$key]
       ]);
    
     } // end of loop
   
   }); // end of DB  
      }  // end of try

      catch (Exception $e) {
        return FALSE;
      }
        
  return TRUE;
 } // end of function

public static function changeStatus($id,$courseId,$semId,$IsPass)
{
  try {
    
    DB::transaction(function () use($id,$courseId,$semId,$IsPass)
    {

    foreach ($courseId as $key => $value) {
      
      if($IsPass==0)
        {$IsPass = $IsPass;}

      else
      {
        $obj = new UpdateMarks;
        $IsPass = $obj->getIsPass($value,$id,$IsPass);
      }
      // first change IsPass col in stdexaminfo
      DB::table('stdexaminfo')->where([
      ['rollNo','=',$id],
      ['courseId','=',$value]
      ])->update(['IsPass' => $IsPass]);

      // second change in stdedustatus
      DB::table('stdedustatus')->where([
      ['rollNo','=',$id],
      ['sems','=',$semId[$key]]
      ])->update(['semsStatus' => 0]);
    
    // entry in crud table for IsPass
      DB::table('crud')->insert([
     
    'staffId'=>session('accInfo')[0]->id,
    'id'     => $id,
    'colName'=> 'IsPass',
    'chVal'=> $IsPass,
    'prevVal'=> 1,
    'tableName'=> 'stdexaminfo',
    'status'=> 0,
    'comment'=> $value
      ]);

      
     // now entry in notification table for IsPass 
     
      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
        'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'IsPass',
        'comment'=> $value
       ]);


      

  } // end of foreach
     
     
  });// end of DB

  }  //end of try
   catch (Exception $e) {
    return FALSE;
  }
  
  return TRUE;

} // end of function 


public function getIsPass($courseId,$id,$status)
{
  

  //  get student batch
$batch = DB::table('stdinfo')
         ->join('batch','stdinfo.doa','=','batch.year')
         ->select('batch.batch')
         ->where('rollNo','=',$id)
         ->first();
   $batch = $batch->batch;

  // now return key according to values
    
   $res = DB::table('credit_mode')->where([
     ['batch','=',$batch],
     ['courseCode','=',$courseId]
    ])->select('IsTheory','IsPractical')
      ->first();
  
  // means complete subject failed
  if($res->IsTheory==1 && $res->IsPractical!=1)
    {return 0;}

else if($res->IsTheory!=1 && $res->IsPractical==1)
  {return 0;}

else if($res->IsTheory==1 && $res->IsPractical==1)
  {return $status;}
}


}  // end of class
