<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\ForgetPassword;
use App\Profile;
use App\CRUD;
use DB;
use App\Employees;
use Keygen;

// have to work on change and store...
class ResetPasswordController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_true')->except([]);

        $this->middleware('reset_confirmation')->except('index');

    }

    public function index(Request $req){
    	
        //validate 

    	$res=$this->validate($req, [
            'email' => 'required|email',
        ]);
        
        if(\App\Employees::activeEmail(request(['email']))){

            //email exists

             session(['token' => Keygen::numeric(20)->generate() ]);

             try{

                $res= \Mail::to(request('email'))->send(new ForgetPassword());

             }catch(\Exception $e){

                session()->flash('unsuccess','Some problem occured while sending mail.. check your internet connection!');
         
                return redirect('/');
                
             }


            //flash message when mail has been sent successfully 
        
            session()->flash('success','Your email has been sent successfully check your inbox ,all mails and spam folder!');

            //saving email
        
            session(['email' => request('email')]); 

            //redirection
        
            return redirect()->route('login');
        
        }else{

          //if the email is active

          return redirect()->route('login')->withErrors([
                'message' => 'Incorrect email try again'
            ]);

        }

    }

    public function change(){

        if(request('_to')!=session('token')){
            return redirect('/');
        }
        return view ('auth.resetpass');
    }

    public function store(Request $req){
        //validate 

        $res=$this->validate($req, [

            'password' => 'required|confirmed|min:6'

        ]);

        $res=ResetPasswordController::passwordValidation();

        //dd($res);

        if($res==1){

            $email= session('email');

            DB::transaction(function () {

                $email= session()->pull('email', '0');

                $old=Employees::passByEmail(['email' => $email]);

                $res=Profile::resetPass(['email'=> $email ,'new' => request('password')]);

                    if ($res) {       
                                 
                        $res2=CRUD::passReset(['staffid' => session('accInfo')[0]->id , 'new'=> request('password'),'old'=>$old[0]->pass,'id'=>$old[0]->staffid]);


                        request()->session()->put('successfull', 'Password has been updated!');
                                            
                    }
                
            });

            return redirect()->route('login');

        }else{

             session()->flash('danger','Invalid password!');

            return redirect('/login/resetPassword?_to='.session('token'));

        }

    }


    public static function passwordValidation(){
        $countNum=0;
        $countUppercase=0;
        $countLowercase=0;
        
        $i=0;
        $char='';

        while ($i < strlen(request('password'))){

            $char=request('password')[$i];

            if (is_numeric($char)) {

                $countNum++;

            } else {

                if($char==strtoupper($char)){

                    $countUppercase++;

                }else if($char==strtolower($char)){

                    $countLowercase++;

                }

            }

            $i++;
            
        }                

        if($countNum < 1  || $countUppercase < 1 || $countLowercase < 1){

            return 0;

        }else{
            return 1;
        }   
    }

}
