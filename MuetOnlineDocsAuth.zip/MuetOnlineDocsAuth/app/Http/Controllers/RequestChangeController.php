<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\RequestForChange;

class RequestChangeController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }

    public function sendMail(Request $request){
       
       //validate request
    	$this->validate($request,[
           'email' => 'required|email',
           'body' => 'required'
    	]);

    
          // send email 
    	$res = Mail::to($request->email)
      ->send(new RequestForChange());
    	if(Mail::failures()){
         
          return redirect('/dashboard/students')->with('message',"Some errors occur please try again!");

    		
    	}
    	else{
    		
         return redirect('/dashboard/students')->with('message',"Your email has been sent successfully check your inbox ,all mails and spam folder!");

    	}
    }
}
