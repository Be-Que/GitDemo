<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Profile;
use App\Employees;
use App\CRUD;
use DB;
use Hash;
use Storage;

class SettingController extends Controller
{
    public function __construct(){
        
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

    }

    public function index(){

    	return view('dashboard.settings');
    
    }
    public function store(Request $req){

        $res=$this->validate($req, [
            'email' => 'required|email'
        ]);


    	DB::transaction(function () {

	    	$res=Employees::updateEmail(['email'=>request('email'),'id'=>session('accInfo')[0]->id]);

	    	if ($res=='-1') {

	    		request()->session()->put('Unsuccessfull', 'Email not available kindly enter any other email!');
	    	}else{

                request()->session()->put('Successfull', 'Email updated successfully!');

	            if ($res==1) {

	                $res2=CRUD::updateEmail(['staffid'=>session('accInfo')[0]->id,'id'=>session('accInfo')[0]->id,'old' => session('accInfo')[0]->email,'new' => request('email')]);

	            }

	            session('accInfo')[0]->email=request('email');
	    		
	    	}
	    });

    	return redirect('/dashboard/settings');
    
    }

    public function getPassword(){

    	$res = Employees::passByEmail(['email'=>session('accInfo')[0]->email]);

        if (Hash::check(request('curr_password'),$res[0]->pass)) {
            $res= true;
        }else{
            $res= false;
        }
    	
		return response()->json($res);
    }

     public function changePass(){

        $res=$this->validate(request(), [
            'password' => 'required|confirmed|min:6' 
        ]);

        SettingController::passwordValidation();

        DB::transaction(function () {
            
            $old=Employees::passByEmail(['email' => session('accInfo')[0]->email]);


            if (Hash::check(request('password'),$old[0]->pass)) {

                //if password is the same as the old so no need to change the password

                request()->session()->put('Message', 'Password was not updated as you entered the same password!');

            }else{

                $res=Employees::updatePass(['pass'=>request('password'),'id'=>session('accInfo')[0]->id]);

                request()->session()->put('Successfull', 'Password updated successfully!');

               $res2=CRUD::passReset(['staffid'=>session('accInfo')[0]->id,'id'=>session('accInfo')[0]->id,'old' => $old[0]->pass,'new' => request('password')]); 
            }

            

        });

        return redirect('/dashboard/settings');
     }

     public static function passwordValidation(){
        $countNum=0;
        $countUppercase=0;
        $countLowercase=0;
        
        $i=0;
        $char='';

        while ($i < strlen(request('password'))){

            $char=request('password')[$i];

            if (is_numeric($char)) {

                $countNum++;

            } else {

                if($char==strtoupper($char)){

                    $countUppercase++;

                }else if($char==strtolower($char)){

                    $countLowercase++;

                }

            }

            $i++;
            
        }                

        if($countNum < 1  || $countUppercase < 1 || $countLowercase < 1){

            session()->flash('Unsuccessfull','Invalid password!');

            return redirect('/dashboard/settings');

        }
        
    }



     public function changePic(Request $req){

        $res=$this->validate($req, [
            'pic'  => 'image:jpeg,jpg,png | max:64'
        ]);

        DB::transaction(function () { 

            //old pic
            $pic=Employees::pic(['id'   => session('accInfo')[0]->id ] );

            //checking if request has pic

            if (request()->hasFile('pic')) {
                
                //storing file to the directory

                request()->file('pic')->store('public/uploads/staff');

                //storing the file uri to the database

                $file_name = request()->file('pic')->hashName();


                //storing the file uri to the database

                $res=Employees::setPic(['id'=> session('accInfo')[0]->id, 'pic'=> $file_name]);


                if($res!=1){

                    return redirect('/dashboard/settings')->withErrors([
                    'message' => 'Error while saving picture'
                    ]);

                }else{
                    session('staffInfo')[0]->pic=$file_name;
                    
                    if($pic!=null ){
                        //CRUD entry because emp pic is updated

                        $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' =>  session('accInfo')[0]->id,'new'=> $file_name,'old' => $pic]);
                            
                    }else{

                        //CRUD entry because emp pic is not updated and the prev pic value was null
                        $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' => session('accInfo')[0]->id ,'new'=> $file_name,'old' => "null"]);

                            
                    }
                }
            }

        });

        request()->session()->put('Successfull', 'Picture was updated successfully!');

        return redirect('/dashboard/settings');
     }
}
