<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Login;
use App\Prevs;
use App\CRUD;
use App\Employees;
use App\Student;
use App\Visits;


class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }


     public function index(){

        // checking previleges...
        $previleges=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

        $content=[];

        foreach($previleges as $prev){

                if($prev->id ==13 || $prev->id ==8 || $prev->id ==9 || $prev->id ==10){

                    $content['emp']=true;
                    
                }

             // added by hina

             if($prev->id==1 || $prev->id==2 || $prev->id==3 || $prev->id==4 || $prev->id==12)
             {
                $content['verified'] = true;
             }

             if($prev->id==5 || $prev->id==6 ||
              $prev->id==7 ||$prev->id==11)
              {
                $content['student'] = true;
              }   
              // end by hina
        }

        $result=array();

        if(array_key_exists ( 'emp' , $content )){

            $res=Employees::getFewEmployees();

            $result['emp-details'] = $res;
            
        }
         $result['graph'] = true;
             // added by hina

         if (array_key_exists ( 'verified' , $content )) {

            // we have to add here code to get the data of the graph portion 

            $result['verified'] = true;

        }

         if (array_key_exists ( 'student' , $content )) {

            // we have to add here code to get the data of the graph portion 

            $result['student'] = true;

        }  // end by hina

        //add student portion here 
        $result1 = Student::getRecentVerified(); 
        $visits  = Visits::getVisits();
   $certificate  = Visits::certificateSearch(); 
      $result2   = Student::graduatingStd();   

        return view('dashboard.index',compact("result","result1","visits","certificate","result2"));
    
    }



    public function profile(){

    	//get Employee info....

        $res=Login::getData();

        $res2=Prevs::rolePrevs(['id'=>session('accInfo')[0]->role]);

        $res3=CRUD::crudOp(['id'=>session('accInfo')[0]->id]);
        //dd($res4);

        $empCr=array();
        $empUp=array();
        $empDel=array();
        $roleCr=array();
        $stdUp=array();
        $stdDel=array();
        $stdVer=array();
        $stdRep=array();

        foreach ($res3 as $value) {

            if($value->id !=session('accInfo')[0]->id ){
                if ($value->status==1) {

                    if ($value->tableName=="empaccountsinfo"){
                        
                        array_push($empCr, $value);

                    }else if ($value->tableName=="role") {
                        
                        array_push($roleCr, $value);

                    }

                }else if($value->status==0){

                    if ($value->tableName=="empaccountsinfo" || $value->tableName=="staff"){

                        if($value->colName=="status"){

                            array_push($empDel, $value);

                        }else{

                            array_push($empUp, $value);

                        }
                    
                    }else if($value->tableName=="stdinfo" || $value->tableName=="stdexaminfo"){

                        if($value->chVal==-1){

                            // deletion

                            array_push($stdDel, $value);


                        }else if($value->chVal==-2){

                            // reported

                            array_push($stdRep, $value);

                        }else{

                            //updation

                            array_push($stdUp, $value);

                        }

                    }

                }else if($value->status==2){

                    // verified

                    array_push($stdVer, $value);

                }
            }
        }

        $crud=['empCr' => count($empCr), 'roleCr' => count($roleCr), 'empUp' => count($empUp), 'stdUp' => count($stdUp), 'empDel' => count($empDel), 'stdDel' => count($stdDel), 'stdVer' => count($stdVer), 'stdRep' => count($stdRep)];
    	
        return view('dashboard.profile',compact("res","res2","crud"));
    
    }
}
