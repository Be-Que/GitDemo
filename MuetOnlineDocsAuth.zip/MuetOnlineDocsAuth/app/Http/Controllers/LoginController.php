<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Login;


class LoginController extends Controller
{

	public function __construct()
    {
        $this->middleware('auth_true')->except(['destroy']);

        $this->middleware('auth_false')->except(['index','store']);
    }

    public function index(){
    	
        return view ('auth.login');
        
    }

    public function store(Request $req){

    	//validate 

    	$res=$this->validate($req, [
            'email' => 'required|email',
            'pass' => 'required' 
        ]);


        //authenticating using database

        $auth=Login::auth(request(['email','pass']));

        if(!$auth){

            return redirect()->route('login')->withErrors([
                'message' => 'Email or password incorrect'
            ]);

        }

        
        return redirect()->route('dashboard');

    }

    public function destroy(){

         session()->flush();

         return redirect()->route('login');

    }
}
