<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Prevs;


class GetPrevController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }

    public static function getStaffPrev()
    {

     $previlages = Prevs::rolePrevs(['id'=>session('accInfo')[0]->role]);

     $prev = [];
  foreach ($previlages as $value) {
   
    if($value->id==1)
   {
      $prev['1']= true;
     }

   if($value->id==2)
   {
      $prev['2']= true;
     }

  if($value->id==3)
   {
      $prev['3']= true;
     }

    if($value->id==4)
   {
      $prev['4']= true;
     }
     
     if($value->id==5)
   {
      $prev['5']= true;
     }

     if($value->id==6)
   {
      $prev['6']= true;
     }

     if($value->id==7)
   {
      $prev['7']= true;
     }
    
     if($value->id==11)
   {
      $prev['11']= true;
     }

     if($value->id==12)
   {
      $prev['12']= true;
     }
}
return $prev;
}
   
}
