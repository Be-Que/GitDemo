<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CRUD;
use App\Employees;
use App\Roles;
use App\StudentDetail;
use App\Course;


class LogsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

       
        
    }

    public function index(){

      if (request('q')==null || request('q')=='date') {

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getData();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }elseif (request('q')=='chMadeByMe') {

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getSpecificData(['type'=>1]);

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }elseif (request('q')=='creations'){

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getCreations();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }elseif (request('q')=='updations'){

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getUpdations();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }elseif (request('q')=='deletions'){

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getDeletions();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }

// Added by Hina

      elseif (request('q')=='verified'){

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getVerified();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }

      elseif (request('q')=='reported'){

        if(session('accInfo')[0]->role==1){

          $res=CRUD::getReported();

        }else{

          $res=CRUD::getSpecificData(['type'=>1]);

        }

      }
 
 // end modification by hina here


      else{

        return redirect('/dashboard/log');
      }

        $res2=LogsController::logs($res);

        $search=true;

        return view('dashboard.activity_log',compact("res2","search"));
       
    }

    public static function logs($res){
        
      //changes made by  employee names
      $chMadeBy=array();

      //changes made on employee names or student
      $chMadeOn=array();

      $courseNames=[];

      $rolenames=[];


       foreach($res as $value){

          $ch1=Employees::getDataLogs(['id' => $value->staffid]);

          if($value->tableName=='role'){

            if($value->chVal!=null && $value->chVal==0){

              $ch2=$value->comment;

            }else if($value->chVal==null){

              $ch2=Roles::roleNameLogs(['role' => $value->id]);

            }   
              
            array_push($chMadeOn, $ch2);

          }

// Added by hina

elseif($value->tableName=='stdinfo'||$value->tableName=='documents'||$value->tableName=='stdexaminfo')
{
  
  // that means changes made on is student

  $ch2 = StudentDetail::getLogInfo($value->id);
  array_push($chMadeOn,$ch2);
  if($value->comment !=null)
  {
 
 if(count($courseNames)==0 || !(array_key_exists($value->comment, $courseNames))){

    $name=Course::getCourseName([ 'code' => $value->comment]);

  $courseNames[$value->comment] = $name[0]->courseName;
   }
  
  }  // ends of if
}
      
      else{

        $ch2=Employees::getDataLogs(['id' => $value->id,'purpose'=>'logs']);

        if($value->colName == 'role'){

          $chVal=Roles::roleNameLogs(['role' => $value->chVal])[0]->name;
          $prevval=Roles::roleNameLogs(['role' => $value->prevVal])[0]->name;
          $rolenames["$value->id"]=['prevVal'=>$prevval,'chVal'=> $chVal];

        }

        array_push($chMadeOn, $ch2);

      }

          array_push($chMadeBy, $ch1);
          
        }

          return array('crud' => $res, 'changesMadeBy' => $chMadeBy, 'changesMadeOn' => $chMadeOn,'courseNames'=>$courseNames,'rolenames'=>$rolenames);
        
    }

    public function search(Request $req){

      $res=$this->validate($req, [
          'search' => 'required|date',
      ]);

      $res=CRUD::getSpecificData(['type'=> -1, 'date'=>request('search')]);

      $res2=LogsController::logs($res);

      $search=true;

      return view('dashboard.activity_log',compact("res2","search"));
    }
}
