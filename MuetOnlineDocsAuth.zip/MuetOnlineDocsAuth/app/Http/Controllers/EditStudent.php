<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UpdateStdInfo;
use Validator;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use Session;



class EditStudent extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }

    public function updateInfo(Request $request)
    {
         $id = $request->id;
        $cnic = $request->cnic; 
        $cnic = str_replace("-", '', $cnic);
        $filename = $request->imageName;
        // valiadte data
        $this->validation($request);
      
             
  // check if image change or not and then upload in folder
   if($request->hasFile('pic'))
{   
    $file = $request->file('pic');
    $extension = $file->getClientOriginalExtension();
     $filename  = '('.date('Y-m-d-h-m-s').')('.$id.').'.$extension;
// store file
Storage::putFileAs('public/uploads/students',$file,$filename);
  
  }


    $newdata = array('fullname'=>$request->fullname,'fatherName'=>$request->fathername,'surname'=>$request->surname,'gender'=>$request->gender,
        'dob'=>$request->dob,'cnic'=>$cnic,
        'mbNo'=>$request->mobno,'domicile'=>$request->domicile,'country'=>$request->country,
        'province'=>$request->province,'addr'=>$request->address,'email'=>$request->email,'enrollmentNo'=>$request->enrollmentNo,'deptId'=>$request->dept,'pic'=>$filename);
  
  
  $olddata = array('fullname'=>$request->oldname,'fatherName'=>$request->oldfathername,'surname'=>$request->oldsurname,'gender'=>$request->oldgender,
        'dob'=>$request->olddob,'cnic'=>$request->oldcnic,
        'mbNo'=>$request->oldmobno,'domicile'=>$request->olddomicile,'country'=>$request->oldcountry,
        'province'=>$request->oldprovince,'addr'=>$request->oldadd,'email'=>$request->oldmail,'enrollmentNo'=>$request->oldenrollment,'deptId'=>$request->olddept,
        'pic'=>$request->imageName);

  $lables = array('fullname'=>'fullname','fatherName'=>'fatherName','surname'=>'surname','gender'=>'gender','dob'=>'data of birth','cnic'=>'cnic','mbNo'=>'mobile number','domicile'=>'domicile','country'=>'country','province'=>'province','addr'=>'address','email'=>'email','enrollmentNo'=>'enrollmentNumber','deptId'=>'departmentName','pic'=>'picture');

     $changefield = array_diff($newdata,$olddata);

if(count($changefield) == 0)
{
  Session::flash('message',"No updation occur beacuse you don't change any field");

  return response()->json(['0' => "No updation occur beacuse you don't change any field "]);
}
else

{

     // now get the old values of change fields

     $oldfield = array();
     $change   = array();
     $description = array();
     foreach ($changefield as $key => $value) {
       
       array_push($oldfield, $olddata[$key]);
       array_push($change, $key);
      array_push($description,$lables[$key]);
     }
    
    // now send for update
 $update = UpdateStdInfo::updateRecord($id,$changefield,$oldfield,$description);
   
   if($update)
   { 
     $changefields = implode(",",$description);
     
    Session::flash('message',$changefields.' of '.$id.' has been successfully updated!');

    return response()->json(['0'=> 1 ,$id,$change]);
    //return 
   }
   else
   {
    return response()->json(['0'=>'Error Occur']);
   }     

 
}

}
// validate input fields

public function validation($output)
{
	return   $this->validate($output,[
     'fullname'   => 'regex:/^[a-zA-Z ]+$/|max:255|required',
     'fathername' => 'regex:/^[a-zA-Z ]+$/|max:255|required',
     'surname'    =>  'regex:/^[a-zA-Z ]+$/|max:255|required',
     'gender'     => 'required',
      'dob'       => 'required|date',
      'cnic'      => 'regex:/\d{5}-\d{7}-\d/|required',
      'mobno'     => 'required|digits:11',
      'address'   =>'required',

     'email'      => 'required|email|max:255',
     'domicile'   => 'required',
     'country'    => 'required',
     'province'   =>'required',
    'enrollmentNo'=> 'required',
    'dept'        => 'required',
    'doa'         => 'required|date',
    'pic'       => 'image:jpeg,jpg,png | max:64'

    ]);
      
}



}// end of controller 
