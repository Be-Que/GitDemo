<?php

namespace App\Http\Middleware;

use Closure;

class auth_true
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        //if user is already logged in as session is not null

        if (session('staffInfo')!=null && session('accInfo')!=null) {
            return redirect('/dashboard');
        }

        return $next($request);
    }
}
