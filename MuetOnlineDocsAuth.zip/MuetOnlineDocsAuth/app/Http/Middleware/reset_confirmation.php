<?php

namespace App\Http\Middleware;

use Closure;

class reset_confirmation
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   
        if ( session('email')==null ) {
            
            return redirect('/');

        }

        return $next($request);
    }
}
