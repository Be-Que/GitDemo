<?php

namespace App\Http\Middleware;

use Closure;
use App\Prevs;

class authCrEdit
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $content= Prevs::rolePrevs(['id' => session('accInfo')[0]->role]); 
         foreach($content as $value){
            if($value->id==8 || $value->id==9){
                return $next($request);
            }

         }
        
        abort(404);
    }
}
