<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class CRUD extends Model
{
    //checked
    public static function scopePassReset($query,$passReset){

        //whenever user password is updated 
        
        $res=DB::table('crud')->insert([
            
            'staffid' => $passReset['staffid'],
            'id' =>  $passReset['id'],
            'colName' =>  'pass(password)',
            'chVal' =>  bcrypt($passReset['new']),
            'prevVal' =>  $passReset['old'],
            'tableName' => 'empaccountsinfo' ,
            'status' => 0
        ]);

        return $res;

    }

    public static function scopeUpdateRole($query,$role){

        //whenever user password is updated 
        
        $res=DB::table('crud')->insert([
            
            'staffid' => $role['staffid'],
            'id' =>  $role['id'],
            'colName' =>  'role',
            'chVal' =>  $role['new'],
            'prevVal' =>  $role['old'],
            'tableName' => 'empaccountsinfo' ,
            'status' => 0
        ]);

        return $res;

    }

    //checked
    public static function scopeEmpDelete($query,$empDelete){

        //whenever user password is updated 
        
       $res=DB::table('crud')->insert([
            
            'staffid' => session('accInfo')[0]->id,
            'id' =>  $empDelete['id'],
            'colName' =>  'status',
            'chVal' =>  '0',
            'prevVal' =>  '1',
            'tableName' => 'empaccountsinfo' ,
            'status' => 0
        ]);

        return $res;

    }

    //checked
    public static function scopePerEmpDelete($query,$empDelete){

        //whenever user password is updated 
        
       $res=DB::table('crud')->insert([
            
            'staffid' => session('accInfo')[0]->id,
            'id' =>  $empDelete['id'],
            'colName' =>  'status',
            'chVal' =>  '-1',
            'prevVal' =>  '1',
            'tableName' => 'empaccountsinfo' ,
            'status' => 0
        ]);

        return $res;

    }

    //checked
    public static function scopeCrudOp($query,$op){

        $res=DB::table('crud')
            
            ->select('id','colName','chVal','prevVal','tableName','status')
            
            ->where('staffid', $op['id'])
            
            ->get();

        return $res;
    }


    //checked
    public static function  scopeUpdateEmail($query,$updateEmail){

        $res=DB::table('crud')->insert([
            
            'staffid' => $updateEmail['staffid'],
            'id' =>  $updateEmail['id'],
            'colName' =>  'email',
            'chVal' =>  $updateEmail['new'],
            'prevVal' =>  $updateEmail['old'],
            'tableName' => 'empaccountsinfo' ,
            'status' => 0
        ]);

        return $res;

    }
    
    public static function scopeStaffPic($query, $staffPic){

        //whenever staff picture is updated 
        
        $res=DB::table('crud')->insert([
            
            'staffid' =>  $staffPic['staffid'],
            'id' =>  $staffPic['id'],
            'colName' =>  'pic(picture)',
            'chVal' =>  $staffPic['new'],
            'prevVal' =>  $staffPic['old'],
            'tableName' => 'staff' ,
            'status' => 0
        ]);

        return $res;
    }

    //checked
    public static function getData(){

        $res=DB::table('crud')
            
            ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

            ->orderBy('created_at', 'desc')

            ->paginate(10);

        return $res;
    }

    public static function  scopeGetSpecificData($query,$data){

        if($data['type']==1){

            $res=DB::table('crud')
            
            ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

            ->where('staffid',session('accInfo')[0]->id)

            ->orderBy('created_at', 'desc')

            ->paginate(10);

            return $res;

        }else if($data['type']==-1){

            if(session('accInfo')[0]->role==1){

                $res=DB::table('crud')
            
                        ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

                        ->whereBetween('created_at', [$data['date'].' 00:00:00', \Carbon\Carbon::parse($data['date'].' 00:00:00')->addDays(1)])

                        ->orderBy('created_at', 'desc')

                        ->paginate(10);

            }else{

                $res=DB::table('crud')
            
                        ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

                        ->whereBetween('created_at', [$data['date'].' 00:00:00', \Carbon\Carbon::parse($data['date'].' 00:00:00')->addDays(1)])

                        ->where('staffid',session('accInfo')[0]->id)

                        ->orderBy('created_at', 'desc')

                        ->paginate(10);

            }

            return $res;

        }


        $res=DB::table('crud')
            
            ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

             ->where('staffid','!=',session('accInfo')[0]->staffid)

            ->orderBy('created_at', 'desc')

            ->paginate(10);

        return $res;
    }

    public static function getCreations(){

        $res=DB::table('crud')
            
            ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at')

            ->where('status',1)

            ->orderBy('created_at', 'desc')

            ->paginate(10);

            return $res;

    }

    public static function getUpdations(){

        $res=DB::table('crud')
            
            ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

            ->where('status', '=', 0)

            ->where('colName','!=' ,'status')

            ->orderBy('created_at', 'desc')

            ->paginate(10);

            return $res;

    }

    public static function getDeletions(){

        $res=DB::table('crud')
            
        ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')

        ->where(['status'=> 0, 'colName' => 'status', 'chVal' => '0','tableName'=>'empaccountsinfo'])
        ->orWhere([
            ['status', 0],
            ['colName','status'],
            ['chVal', -1],
            ['tableName', 'stdinfo']

            ])

            ->orderBy('created_at', 'desc')

            ->paginate(10);

            return $res;

    }

  // Added By Hina!
  
  public static function getVerified()
  {
    $res=DB::table('crud')
            
         ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')
         ->where('status','=',2)
          ->orderBy('created_at', 'desc')

            ->paginate(10);

            return $res;

  }   

public static function getReported()
{

        $res=DB::table('crud')
            
         ->select('staffid','id','colName','chVal','prevVal','tableName','status','created_at','comment')
         ->where([
            ['status', 0],
            ['colName','status'],
            ['chVal', -2],
            ['tableName', 'stdinfo']
            ])
          ->orderBy('created_at', 'desc')
          ->paginate(10);

            return $res;
}


 // end modification by hina here

    public static function scopeRoleCreate ($query, $roleCreate){

        //whenever role is created 

        $res=DB::table('crud')->insert([
            
            'staffid' => $roleCreate['staffid'],
            'id' => $roleCreate['id'],
            'tableName' => 'role',
            'status' => 1
        ]);

        return $res;
    }

    public static function scopeEmpCreate ($query, $data){

        //whenever role is created 

        $res=DB::table('crud')->insert([
            
            'staffid' => $data['staffid'],
            'id' => $data['id'],
            'tableName' => 'empaccountsinfo',
            'status' => 1
        ]);

        return $res;
    }

    public static function scopeEmpActivate($query,$data){

        $res=DB::table('crud')->insert([
            
            'staffid' => $data['staffid'],
            'id' => $data['id'],
            'tableName' => 'empaccountsinfo',
            'colName' => 'status',
            'chVal' => 1,
            'prevVal' => 0,
            'status' => 0
            
        ]);

        return $res;

    }

    public static function scopeRoleDelete($query,$data){

        $res=DB::table('crud')->insert([
            
            'staffid' => $data['staffid'],
            'id' => $data['id'],
            'tableName' => 'role',
            'colName' => 'status',
            'chVal' => 0,
            'prevVal' => 1,
            'status' => 0,
            'comment' => $data['name']
            
        ]);

        return $res;

    }

}
