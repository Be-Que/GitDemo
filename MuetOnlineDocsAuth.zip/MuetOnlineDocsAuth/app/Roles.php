<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Roles extends Model
{
    public static function roles(){
    	
    	$res=DB::table('role')->select('id','name')->where('status',1)->get();

    	return $res;
    }

    //checked
    public static function getRoles(){
        
        $res=DB::table('role')->select('id','name','desc')->where('status',1)->orderby('id')->get();

        return $res;
    }


    public static function scopeRoleName($query,$roleName){

        // role name
        $role=DB::table('role')->select('name','desc')->where('id','=', $roleName['role'])->where('status',1)->get();

        return $role;

    } 

     public static function scopeRoleNameLogs($query,$roleName){

        // role name
         $role=DB::table('role')->select('name')->where('id','=', $roleName['role'])->get();

        return $role;

    } 

    //checked
    public static function scopeExist($query,$roleName){
        
        //checking if rolename is unique....

        $role=DB::table('role')->select('name')->where('name',$roleName['val'])->where('status',1)->get();

        if(count($role)>0){
            //role exists true
            return true;
        }else{
            return false;
        }

    }

    //checked
    public static function scopeRoleCreate($query,$role){

        $res=DB::table('role')->insert([

            'id' => $role['id'],
            'name' => $role['name'],
            'desc' => $role['desc']

        ]);

        return $res;

    }

    public static function scopeRoleDel($query,$data){

        $res=DB::table('role')
                ->where('id',$data['id'])
                ->where('status',1)
                ->update(['status' => 0]); 

        return $res;

    }

    public static function scopeCheckEmpRole($query,$data){

        $res=DB::table('empaccountsinfo')->select('staffid')
                ->where('status','!=',-1)
                ->where('role','=',$data['role'])
                ->get();

        return count($res);

    }
}
