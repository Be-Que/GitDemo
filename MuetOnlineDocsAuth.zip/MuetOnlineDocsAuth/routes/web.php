<?php

Route::get('/', 'LoginController@index')->name('login');

Route::get('/dashboard','HomeController@index')->name('dashboard');

Route::post('/dashboard', 'LoginController@store');

Route::get('/logout', 'LoginController@destroy');

Route::post('/login/forgetPassword', 'ResetPasswordController@index');

Route::get('/login/resetPassword','ResetPasswordController@change');

Route::get('/dashboard/employees', 'EmployeeController@index');

Route::get('/employees/search', 'SearchController@searchAjax');

Route::get('/employees/search/result', 'SearchController@index');

Route::post('/employees/search', 'SearchController@search');

// create modal
Route::get('/employee/create','EmployeeController@create');

Route::post('/employee/create','EmployeeController@store');

Route::get('/employee/checkId','EmployeeController@checkId');

Route::get('/employee/checkEmail','EmployeeController@checkEmail');

Route::get('/employees/roles','EmployeeController@checkRoleName');

Route::get('/dashboard/profile','HomeController@profile');

Route::get('/dashboard/settings','SettingController@index');

Route::get('/dashboard/settings/edit','SettingController@store');

Route::post('/settings/checkPass','SettingController@getPassword');

Route::post('/dashboard/settings/editPass','SettingController@changePass');

Route::post('/dashboard/settings/editPic','SettingController@changePic');

Route::get('/dashboard/log','LogsController@index');

Route::get('/dashboard/account_rights','AccountsRightsController@index');

Route::get('/account_rights/create','AccountsRightsController@create');

Route::post('/account_rights','AccountsRightsController@store');

Route::get('/account_rights/info','AccountsRightsController@accRightsInfo');

Route::post('/login/resetPassword', 'ResetPasswordController@store');

//delete modal
Route::get('/employees/delete','EmployeeController@deleteModal');

Route::post('/employees','EmployeeController@destroy');//soft deleting employees

//view modal
Route::get('/employees/view','EmployeeController@viewData');

// edit modal
Route::get('/employees/edit','EmployeeController@getData');

Route::post('/employees/edit/saveChanges','EmployeeController@saveChanges');

Route::get('/logs/search','LogsController@search');

Route::get('/notification/checked','NotificationController@lastChecked');

Route::post('/employees','EmployeeController@destroy');//soft deleting employees

Route::get('/notifications','NotificationController@index');


//hina routes


Route::get('/dashboard/students','StudentController@showStudent');

Route::get('/dashboard/verifiedStudents','StudentController@verifiedStudents');


Route::post('/pinfo/update','EditStudent@updateInfo');


Route::post('/transcript/update','EditMarksController@updateMarks');

Route::post('/student/insert','DegreeInfoController@addDegreeInfo');

//to delete student
Route::post('/student/delete','DeleteController@delete');

// when we click edit button complete detail of student will show

Route::get('/edit/{id}','StdDetailController@stdDetail');

Route::post('/student/sendEmail','RequestChangeController@sendMail');

Route::post('/student/report','DeleteController@reportStudent');

// when view button click
Route::get('/dashboard/verifiedStudents/certificate','CertificateController@showInfo');


Route::get('/students/search/results','SearchController@stdIndex');

Route::get('/students/search','SearchController@stdSearchAjax');
Route::post('/students/search','SearchController@searchStd');

Route::get('/verifiedStudents/search','SearchController@verifiedSearchAjax');

Route::post('/verifiedStudents/search','SearchController@verifiedStd');

Route::get('/verifiedStudents/search/results','SearchController@verifiedIndex');

Route::get('/view/{id}','ViewController@showViewModal');

Route::get('/settings/mobno/{id}','ViewController@updateMobNo');

Route::get('/settings/email/{id}','ViewController@updateMail');

Route::get('/settings/address/{id}','ViewController@updateAddr');

Route::get('/settings/currPos/{id}','ViewController@updateCP');

//hina routes


Route::get('/dashboard/students','StudentController@showStudent');

Route::get('/dashboard/verifiedStudents','StudentController@verifiedStudents');


Route::post('/pinfo/update','EditStudent@updateInfo');


Route::post('/transcript/update','EditMarksController@updateMarks');

Route::post('/student/insert','DegreeInfoController@addDegreeInfo');

//to delete student
Route::post('/student/delete','DeleteController@delete');

// when we click edit button complete detail of student will show

Route::get('/edit/{id}','StdDetailController@stdDetail');

Route::post('/student/sendEmail','RequestChangeController@sendMail');

Route::post('/student/report','DeleteController@reportStudent');

// when view button click
Route::get('/dashboard/verifiedStudents/certificate','CertificateController@showInfo');


Route::get('/students/search/results','SearchController@stdIndex');

Route::get('/students/search','SearchController@stdSearchAjax');
Route::post('/students/search','SearchController@searchStd');

Route::get('/verifiedStudents/search','SearchController@verifiedSearchAjax');

Route::post('/verifiedStudents/search','SearchController@verifiedStd');

Route::get('/verifiedStudents/search/results','SearchController@verifiedIndex');

Route::get('/view/{id}','ViewController@showViewModal');

Route::get('/settings/mobno/{id}','ViewController@updateMobNo');

Route::get('/settings/email/{id}','ViewController@updateMail');

Route::get('/settings/address/{id}','ViewController@updateAddr');

Route::get('/settings/currPos/{id}','ViewController@updateCP');
Route::get('/settings/orgName/{id}','ViewController@updateOrgName');


Route::post('/student/restore','DeleteController@restoreStd');

// editing by bushra

Route::get('/students/view','StdDetailController@index');

Route::get('/employees/restore','EmployeeController@restoreModal');

Route::post('/employees/restore','EmployeeController@restore');

Route::get('/account_rights/delete','AccountsRightsController@deleteModal');

Route::post('/account_rights/delete','AccountsRightsController@destroy');