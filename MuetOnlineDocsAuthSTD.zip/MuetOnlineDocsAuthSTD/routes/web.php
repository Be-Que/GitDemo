<?php



Route::get('/', 'WelcomeController@index');

Route::get('/check','RequestHandlerController@index');

Route::get('/certificate','CertificateController@index');

Route::get('/sendMail','MailController@send');


