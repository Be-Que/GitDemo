<div class="container">




<!-- The Modal -->
<div class="modal fade"  id="myModal" >
<div class="modal-dialog modal-lg modWidth" >
<div class="modal-content">

<!-- Modal Header -->
<div class="modal-header headSize">
<h4 class="modal-title text-white btnColor"><b> Pass Certificate</b></h4>
<button type="button" class="close btnColor" data-dismiss="modal"
style="margin-top: -25px;">&times;</button>
</div>


<!-- Modal body -->
<div class="modal-body">

<div class="phone-content">
<span class="contact-title">Full Name:</span>
<span class="phone-number">
 {{ucwords($pinfo->fullname)}}
</span>
</div>
<div class="phone-content">
<span class="contact-title">Father Name:</span>
<span class="phone-number">
	{{ucwords($pinfo->fatherName)}}
</span>
</div>
<div class="phone-content">
<span class="contact-title">RollNo:</span>
<span class="phone-number">
	    {{strtoupper($pinfo->rollNo)}}
</span>
</div>

<div class="phone-content">
<span class="contact-title">CGPA:</span>
<span class="phone-number">
	{{$degreeInfo->cgpa}}
</span>
</div>

<div class="phone-content">
<span class="contact-title">Final Exam Held:</span>
<span class="phone-number">
	{{$degreeInfo->doe}}
</span>
</div>


<div class="phone-content">
<span class="contact-title">Department:</span>
<span class="phone-number">
	   {{ucwords($pinfo->name)}}
</span>
</div>   

<div class="phone-content">
<span class="contact-title">Position:</span>
<span class="phone-number">
	   {{$formatdate['position']}}
</span>
</div>                            
</div>



<!-- Modal footer -->
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
</div>

</div>
</div>
</div>

</div>