<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Welcome</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Main Stylesheet File -->
  <link href="/css/style.css" rel="stylesheet">

 </head>

<body>
<header>
    <!-- header-area start -->
    <div id="sticker" class="header-area"   style="background-color:#445463;">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
               
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="{{URL::to('/')}}">
                  <h3><span>{{ config('app.name') }}</span>Students</h3>
                  
               </a>
              </div>
             
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <!-- header end -->

<header class="p-5" style="margin-left: 10%;margin-top: 10%;">

	<h4 style="font-weight: bolder;color: #333">Page not found</h4>
	<hr>

	<p>The requested page could not be found.</p>
	<hr>

	<p class="text-center">
		&copy; {{\Carbon\Carbon::now()->year}}. {{ config('app.name')}}Students
	</p>
	<hr>

</header>


</body>

</html>
