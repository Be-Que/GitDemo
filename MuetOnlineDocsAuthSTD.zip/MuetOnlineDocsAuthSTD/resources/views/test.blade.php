<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Welcome</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
<meta name="csrf-token" content="{{csrf_token()}}">

 
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="/lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="/lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="/lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link href="/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="/lib/animate/animate.min.css" rel="stylesheet">

  <!-- Nivo Slider Theme -->
  <link href="/css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="/css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="/css/responsive.css" rel="stylesheet">

  <!--model styles-->

 <link href="/css/style1.css" rel="stylesheet">
 <style type="text/css">
   
   .cntform input, .cntform textarea{

    border:1px solid #eaeaea;

   }
 </style>
</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="{{URL::to('/')}}">
                  <h3><span>{{ config('app.name') }}</span>Students</h3>
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <!-- <img src="img/logo.png" alt="" title=""> -->
                                </a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                <ul class="nav navbar-nav navbar-right">
                  <li class="active">
                    <a class="page-scroll" href="#home">Home</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#about">About</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#services">Services</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#contact">Contact</a>
                  </li>
                </ul>
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <!-- header end -->

  <!-- Start Slider Area -->
  <div id="home" class="slider-area">
    <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides">
        <img src="/img/slider/muet.jpg" alt="" title="#slider-direction-1" >
        <img src="/img/slider/grad1.jpg" alt="" title="#slider-direction-2"/>
        <img src="/img/slider/docs.jpg" alt="" title="#slider-direction-3" />
        <img src="/img/slider/slider3.jpg" alt="" title="#slider-direction-4" />
      </div>

      <!-- direction 1 -->
      <div id="slider-direction-1" class="slider-direction slider-one">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="slider-content">
                <!-- layer 1 -->
                <div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
                  <h2 class="title1">Verify Your Documents</h2>
                </div>
                <!-- layer 2 -->
                <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                  <h1 class="title2">We help you verify your Degree, Pass Certificate and Transcript</h1>
                </div>
                <!-- layer 3 -->
                <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <a class="ready-btn right-btn page-scroll" href="#searchIdArea">Search your Id to verify</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- direction 2 -->
      <div id="slider-direction-2" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="slider-content text-center">
                <!-- layer 1 -->
                <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <h2 class="title1">Verify Your Documents</h2>
                </div>
                <!-- layer 2 -->
                <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                  <h1 class="title2">We help you verify your Degree, Pass Certificate and Transcript</h1>
                </div>
                <!-- layer 3 -->
                <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <a class="ready-btn right-btn page-scroll" href="#searchIdArea">Search your Id to verify</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- direction 3 -->
      <div id="slider-direction-3" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="slider-content">
                <!-- layer 1 -->
                <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <h2 class="title1">Verify Your Documents</h2>
                </div>
                <!-- layer 2 -->
                <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                  <h1 class="title2">We help you verify your Degree, Pass Certificate and Transcript</h1>
                </div>
                <!-- layer 3 -->
                <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <a class="ready-btn right-btn page-scroll" href="#searchIdArea">Search your Id to verify</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Slider Area -->

  <!-- Start Wellcome Area -->
  <div class="wellcome-area" id="searchIdArea">
    <div class="well-bg" >
      <div class="test-overly"></div>
      <div class="container" >
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="wellcome-text">
              <div class="well-text text-center">
                <h2>Welcome to {{ config('app.name')}}</h2>
                <p>
                  Enter the alpha numeric id at the top of your certificate to verify your certificate.
                </p>


                
                    <input type="text" class="s_email email form-control" id="sus_email" placeholder="Enter your Id" required
                     name="key" autocomplete="off">

                   <!-- <input type="button" id="sus_submit" class="s_submit" value="Search Your Id" onclick="appendKey()"> -->
               <button type="button" id="sus_submit" class="s_submit" value="Search Your Id" onclick="appendKey()" title="search by id"><i class="fa fa-search"></i></button>

      <input type="hidden" name="id" value="" id="id">
      <input type="hidden" name="doctype" value="" id="doctype">

              
<br><br>
<div class="alert alert-danger hidden" style="width: 100%;color: white;font-family: 'Raleway', sans-serif;" role="alert" id="error">
</div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Wellcome Area -->

  <!-- Start About area -->
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About {{ config('app.name') }}</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
                                  <img src="/img/about/download.jpg" alt="">
                                </a>
            </div>
          </div>
        </div>
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <h4 class="sec-head">Verifying your Degree,Pass certifcate and Transcript</h4>
              </a>
              <p>
                This website will help you verify your MUET Degree, Pass certificate and Transcript by showing you the information related to the key or id if the certificates are not fake.
              </p>

              <ul>
                <li>
                  <i class="fa fa-check"></i> Verify your Degree by entering the id written at the top.
                </li>
                <li>
                  <i class="fa fa-check"></i> Verify your Pass Certificate by entering the id written at the top.
                </li>
                <li>
                  <i class="fa fa-check"></i> Verify your Transcript by entering the id written at the top.
                </li>
              </ul>

            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
  <!-- End About area -->

  <!-- our-skill-area start -->
  <div class="our-skill-area fix hidden-sm">
    <div class="test-overly2"></div>
    <div class="skill-bg area-padding-2">
      <div class="container">
        <!-- section-heading end -->
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline services-head text-center">
            <h2 style="color:white;">Our Services</h2>
          </div>
        </div>
      </div>
      <div class="row text-center">
        <div class="services-contents">
          <!-- Start Left services -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                                            <i class="fa fa-code" style="color:white"></i>
                                        </a>
                  <h4  style="color:white;">Website</h4>
                  <p  style="color:white;"> 
                    Using this website you can verify the documents you have by entering the key on the document.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                                            <i class="fa fa-qrcode"  style="color:white;"></i>
                                        </a>
                  <h4  style="color:white;">Mobile Application</h4>
                  <p  style="color:white;">
                    Using our Mobile Application for android devices you can verify your documents by scaning the QR code at the top of the certificate.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          
          
        </div>
      </div>
      </div>
    </div>
  </div>
  <!-- our-skill-area end -->

  <!-- Faq area start -->
  <div class="faq-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Faq Question</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div >
          <div class="faq-details">
            <div class="panel-group" id="accordion">
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
                      <a data-toggle="collapse" class="active" data-parent="#accordion" href="#check1">
                          <span class="acc-icons"></span>What is {{ config('app.name') }} ?
                      </a>
                  </h4>
                </div>
                <div id="check1" class="panel-collapse collapse in">
                  <div class="panel-body">
                    <p>
                      {{ config('app.name') }} is a verification system which is provided by muet to the students so that they can verify and prove that their documents and information is real.
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#check2">
                          <span class="acc-icons"></span> What is the procedure of verification?
                      </a>
                  </h4>
                </div>
                <div id="check2" class="panel-collapse collapse">
                  <div class="panel-body">
                    <p>
                      Enter your id which is present on your certificate in this <a href="#searchIdArea" >section</a>, the website will process your request and show you the relevant information.</p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#check3">
                          <span class="acc-icons"></span>What type of cerificates can be verified by this portal ?
                      </a>
                  </h4>
                </div>
                <div id="check3" class="panel-collapse collapse ">
                  <div class="panel-body">
                    <p>
                      This website allows you to verify your Degree, Pass certificate and Transcript for B.E programme.
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
            </div>
          </div>
        </div>
        
      </div>
      <!-- end Row -->
    </div>
  </div>
  <!-- End Faq Area -->
 
  <!-- Section: contact -->
  <section id="contact" class="home-section nopadd-bot color-dark bg-gray text-center">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-8 col-lg-offset-2">
          <div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
            <div class="section-heading text-center">
              <h2 class="h-bold">Connect With Us</h2>
              <div class="divider-header"></div>
              <p>You can send us your valuable feedback and suggestions using this section.</p>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="container">

      <div class="row marginbot-80">
        <div class="col-md-8 col-md-offset-2">
         
         <!-- message sent successfully message here -->

            <br>
          <form action="" method="post" role="form" class="contactForm" id="contact-form">

            <div class="alert alert-success hidden" id="success" style="color: white;" role="alert">
              Thankyou for providing us your valuable feedback!
            </div>

            <div class="alert alert-danger hidden" id="msgerr" style="color: white;" role="alert">
              Problems!
            </div>

            <div class="alert hidden" id="msgwarning" style="color: white;background-color: orange;" role="alert">
              Problems!
            </div>

            <div class="form-group cntform">
              <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
            </div>
           
              
            <div class="form-group cntform">
              <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email"  required/>
              
            </div>
           
            <div class="form-group cntform">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" 
              required />
  
            </div>
            
            <div class="form-group cntform">
              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" id="message"></textarea>

              <br>
            
            </div>

            <div class="text-center cntform"><button type="button" class="btn btn-primary btn-lg btn-block" id="submitMailBtn" 
              onclick="sendMail()">Send Message</button></div>

          </form>

        </div>
      </div>


    </div>
  </section>
  <!-- /Section: contact -->

  <!-- Start Footer bottom Area -->
  <br><br>
  <footer >
    <div class="footer-area">
      <div class="container">
        <div class="row text-center">

          <div class="footer-content">
              <div class="footer-head">
                <h4>Information</h4>
  
                <div class="footer-contacts">
                  <p><span>Tel:</span> +123 456 789</p>
                  <p><span>Email:</span> muetdocsv.customer@gmail.com</p>
                </div>
              </div>
            </div>

        </div>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <div id="modals"></div>

  <!-- JavaScript Libraries -->
  
  <script src="/js/jquery-1.10.2.js"></script>
  <script src="/lib/jquery/jquery.min.js"></script>
  <script src="/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="/lib/owlcarousel/owl.carousel.min.js"></script>
  <!-- <script src="/lib/venobox/venobox.min.js"></script> -->
  <!-- <script src="/lib/knob/jquery.knob.js"></script> -->
  <script src="/lib/wow/wow.min.js"></script>
 <!-- <script src="/lib/parallax/parallax.js"></script> -->
  <!-- <script src="/lib/easing/easing.min.js"></script> -->
  <script src="/lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <!-- <script src="/lib/appear/jquery.appear.js"></script> -->
  <!-- <script src="/lib/isotope/isotope.pkgd.min.js"></script> -->

  <!-- Contact Form JavaScript File -->
 

  <script src="js/main.js"></script>
 

</body>

<script type="text/javascript">
  
  function appendKey(id)
{


  var key = $('#sus_email').val().trim();
  var key1 = "1"+key;
  
if(key=="")
{
    $('#error').removeClass('hidden');
    $('#error').empty().append('Enter the key!');
}

  else if(key.length!=15)
  {
    $('#error').removeClass('hidden');
    $('#error').empty().append('Key should have 15 characters!');
  }
  else
  {
     $('#sus_submit').attr('disabled','disabled');
 
 $.ajax({
  type: "get",
  url : "/check",
  data: {"key":key1},
  success:function(response)
  {
    if(response==-1)
    {
    $('#sus_submit').attr('disabled',false);
    $('#error').removeClass('hidden');
    $('#error').empty().append('This key does not exist!');
    }
    else if(response==0)
    {
      $('#sus_submit').attr('disabled',false);
     $('#error').removeClass('hidden');
     $('#error').empty().append('This key has been expired!');
    
    }
    else
    {
       
       var id  = response[1];
       var doctype  =  response[2];
     $('#error').addClass('hidden');
    

      $.ajax({
      type: "get", 
      url:"{{URL::to('/certificate')}}",
      data:{"id":id,"doctype":doctype},
      success:function(data)
      {
       
        $('#modals').empty().append(data);
        
        $('#myModal').modal('toggle');
         $('#sus_submit').attr('disabled',false);
       
       
      }

   
      });

    }
  }


 });    
}
}

function sendMail(){
  var name    = $('#name').val().trim();
  var email   = $('#email').val().trim();
  var subject = $('#subject').val().trim();
  var message = $('#message').val().trim();

  $('#success').addClass('hidden');
  $('#msgwarning').addClass('hidden')
  $('#msgerr').addClass('hidden');
  
  if(name==""){

    $('#msgerr').removeClass('hidden');
    $('#msgerr').empty().append('Enter your name!');

  }else{

    if(email=="" || !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))){
    
      $('#msgerr').removeClass('hidden');
      $('#msgerr').empty().append('Enter a valid email!');
    
    }else{

      if(subject=="" ||subject.length<2){

        $('#msgerr').empty().append('Subject must be at least 2 characters long!');  

      }else{

        if(message=="" ||message.length<5){

          $('#msgerr').removeClass('hidden');
          $('#msgerr').empty().append('Message must be at least 5 characters long!');
        
        }else{

          $('#msgerr').addClass('hidden');
          document.getElementById('submitMailBtn').disabled=true;

          $.ajax({
            type : "get",
            url  : "{{URL::to('/sendMail')}}",
            data: {'name':name,'email':email,'subject':subject,'msg':message},
            success:function(response)
            {

              console.log('response '+response);

              if(response==1){
                $('#success').removeClass('hidden');
                $('#msgwarning').addClass('hidden')
                $('#success').empty().append("<b>Thankyou for your valuable feedback and suggestions!</b>");
                $('#name').val("");
                $('#email').val("");
                $('#subject').val("");
                $('#message').val("");
              }else{
                $('#success').addClass('hidden');
                  $('#msgwarning').removeClass('hidden');
                  $('#msgwarning').empty().append('Some problem occured while sending mail.. check your internet connection!');
              } 
              
              document.getElementById('submitMailBtn').disabled=false;
            },

            error: function (jqXHR, exception) {
                console.log('error'.jqXHR);
                // Your error handling logic here..
            }


            });

        }        

      }

    }

  }

}

</script>
</html>
