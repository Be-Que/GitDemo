<b>Customer Feedback....</b><br><br><br>

<b>From:</b> {{$name}} <br><br><b>Email:</b> {{$mail}}<br><br><br><br>

<b>Message</b> :  {{$msg}}  <br>