<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class RequestHandler extends Model
{
    
public static function checkKeyExist($key,$docType,$medium)
{
	$colname = "";
	
	if($docType=='D')
		{$colname = "algD";}

	elseif($docType=="P")
		{$colname = "algP";}
	
	elseif ($docType=="T") 
	    {$colname = "algT";}

    
  $res  =  DB::table('documents')->select('rollNo')
      ->where([
        [$colname,'=',$key],
        ['status','=',1]
        ])->first();

if($res==null)
{
	// that means key not exits on status 1 now check on status 0
   $res1 =	DB::table('documents')->select('rollNo')
      ->where([
        [$colname,'=',$key],
        ['status','=',0]
        ])->first();

  if($res1==null)
  {  // means entered key is wrong
  return -1;
  }
  else
  { // means key exist but expired!
  	
  	return 0; 
  }    
}
  
  $id = $res->rollNo;
  // now insert data in visits table
      RequestHandler::addVisits($medium,$docType);
  return $id;
}

public static function addVisits($medium,$doctype)
{
	if($doctype=='D')
		{$value = 1;}

	elseif($doctype=="P")
		{$value = 2;}
	
	elseif ($doctype=="T") 
	    {$value = 3;}

    DB::table('visits')->insert([
     
     'medium'=> $medium,
     'docType'=> $value    
     ]);

}

}
