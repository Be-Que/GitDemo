<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RequestHandler;


class RequestHandlerController extends Controller
{

   public function __construct()
  {
     $this->middleware('ajax')->only('index');
  }



    public function index(Request $request)
    {
      $key = request('key');
      
      // extract medium from key
      $medium = substr($key,0,1);

      // now extract document type
      $docType = substr($key,-1,1);
      $key     = substr($key,1);

   if(($docType=="D"||$docType=="P"||$docType=="T") &&
     ($medium=="0" || $medium=="1" || $medium=="2"))

  { $res = RequestHandler::checkKeyExist($key,$docType,$medium);

  if($res==-1)
  {
  	return response()->json(['0'=>-1]);
  }
  elseif($res==0)
  {
    return response()->json(['0'=>0]);
  }
  else
   {
    return response()->json(['0'=>1,'1'=>$res,'2'=>$docType]);
  
}

  }
else
  return response()->json(['0'=>-1]);
	
}



}
