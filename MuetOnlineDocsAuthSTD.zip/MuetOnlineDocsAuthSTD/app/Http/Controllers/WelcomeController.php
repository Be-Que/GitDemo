<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Welcome;


class WelcomeController extends Controller
{
    public function index()
    {
    	 $res    = Welcome::getVisits();

    	return view('welcome',compact('res'));
    }
}
