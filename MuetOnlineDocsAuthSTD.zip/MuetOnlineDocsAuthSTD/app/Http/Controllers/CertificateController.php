<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Certificate;



class CertificateController extends Controller
{
  
   public function __construct()
  {
     $this->middleware('ajax')->only('index');
  }


    public function index(Request $request)
    {
     $id      =   $request->id;
     $docType =   $request->doctype;
   

      $pinfo      = Certificate::getPInfo($id);
      $degreeInfo = Certificate::getDegree($id);
     
      $formatdate = CertificateController::dateFormat($degreeInfo->doe,$degreeInfo->position);

      if($docType=="D")
      {
      	return view('certificate.degree',compact('pinfo','degreeInfo','formatdate'));
      }

      elseif($docType=="P")
      {
      	return view('certificate.pass',compact('pinfo','degreeInfo','formatdate'));
      }

      elseif($docType=="T")
      {
      	return view('certificate.transcript',compact('pinfo','degreeInfo','marksInfo','semester','grades','semGpa','formatdate'));
      }
    }




public static function dateFormat($doe,$position)
{
     $date = date_create($doe);
     $year = date_format($date,"Y");
    $month = date_format($date,"m");

  if($month=='01' || $month==1){$name = "January";}

  elseif($month=='02' || $month==2){$name = "February";}

elseif($month=='03' || $month==3){$name = "March";}

elseif($month=='04' || $month==4){$name = "April";}

elseif($month=='05 '|| $month==5){$name = "May";}

elseif($month=='06' || $month==6){$name = "June";}

elseif($month=='07' || $month==7){$name = "July";}

elseif($month=='08' || $month==8){$name = "August";}

elseif($month=='09' || $month==9){$name = "September";}

elseif($month=='10') {$name = "October";}

elseif($month=='11'){$name = "November";}


elseif($month=='12'){$name = "December";}
 
  if($position==1){$value = "First";}
  elseif($position==2){$value = "Second";}
 elseif($position==3){$value = "Third";}
else
  {$value = "None";}

     $res = array('name'=>$name,'year'=>$year,'position'=>$value);
 
  return $res;
}


}
