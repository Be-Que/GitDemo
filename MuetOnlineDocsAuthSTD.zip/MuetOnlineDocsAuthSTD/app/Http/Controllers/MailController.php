<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\ContactMail;

class MailController extends Controller
{
  public function __construct()
  {
     $this->middleware('ajax');
  }

    public function send(Request $req)
    {
    
      define("ADMINMAIL","muetdocsv.customer@gmail.com" );
       

            try{

                $res= Mail::to(ADMINMAIL)
                            ->send(new ContactMail());

             }catch(\Exception $e){

                return response()->json("0");
                
             }

  	if(Mail::failures()){

  		return response()->json("0");
  	}

  	return response()->json("1");
}
}