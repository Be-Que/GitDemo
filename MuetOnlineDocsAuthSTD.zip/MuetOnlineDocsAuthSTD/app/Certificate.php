<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;



class Certificate extends Model
{
     public static function getPInfo($id)
    {
	  $data  =	 DB::table('stdinfo')
	    	 ->join('dept','stdinfo.deptId','=','dept.id')
	    	 ->select('stdinfo.rollNo','stdinfo.fullname','stdinfo.fatherName','dept.name','stdinfo.enrollmentNo','stdinfo.doa')
	    	  ->where('rollNo','=',$id)->first();
    
 return $data;

    }

  public static function getDegree($id)
  {
  	$data = DB::table('documents')
            ->select('dod','position','cgpa','dop','doe')
  	        ->where([
           ['rollNo','=',$id],
           ['status','=',1]
  	       ])->first();

  	   return $data;     
  } 
  
  

}
