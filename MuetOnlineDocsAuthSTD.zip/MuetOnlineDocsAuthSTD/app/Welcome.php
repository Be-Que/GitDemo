<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Welcome extends Model
{
    public static function getVisits()
    {
   $sms =	DB::table('visits')->where('medium','=',0)
    	->count('medium');

    $web = DB::table('visits')->where('medium','=',1)
    	->count('medium');	
    
     $mobile = DB::table('visits')->where('medium','=',2)
    	->count('medium');
  
  $total = $sms+$web+$mobile;

  if($total !=0){

    $sms   =  ($sms/$total)*100;
  $web   =  ($web/$total)*100;
  $mobile = ($mobile/$total)*100;


  }else{

    $sms   = 0;
  $web   =  0;
  $mobile = 0;


  }
  
  $res = array('sms'=>$sms,'web'=>$web,'mobile'=>$mobile);
  return $res;
   }
}
