<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
            <tr>
                <td class="content-cell" align="center">
                   &copy; <?php echo e(date("Y")); ?> 
                   <?php echo e(config('app.name')); ?>Students
                </td>
            </tr>
        </table>
    </td>
</tr>
