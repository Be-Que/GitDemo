<b>Customer Feedback....</b><br><br><br>

<b>From:</b> <?php echo e($name); ?> <br><br><b>Email:</b> <?php echo e($mail); ?><br><br><br><br>

<b>Message</b> :  <?php echo e($msg); ?>  <br>